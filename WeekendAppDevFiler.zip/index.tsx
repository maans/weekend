
import React, { useState, useMemo, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { 
  Users, Utensils, Trash2, FileText, ChevronDown, Database, 
  Search, X, MapPin, Check, 
  Download, ShieldAlert, ShieldCheck, RotateCcw,
  LayoutDashboard, Info, Flame, Compass, CheckCircle2,
  ChevronRight, Lock, AlertCircle, BookOpen, Clock, Printer,
  Calendar, Coffee, Moon, Sun, Sunrise, MoveRight, Dices,
  Zap
} from 'lucide-react';
import * as XLSX from 'xlsx';

// --- HJÆLPEFUNKTIONER ---
const getISOWeek = () => {
  const now = new Date();
  const d = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return String(Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7));
};

// --- FASTE SYSTEM DATA ---
const FIXED_CLEANING = [
  { name: "ARKEN", count: 2 }, 
  { name: "DEN LANGE GANG", count: 3 },
  { name: "GANGENE I TREENIGHEDEN", count: 2 }, 
  { name: "BIOGRAFEN", count: 1 },
  { name: "KUNST", count: 1 }, 
  { name: "KLASSEFLØJEN + TOILETTER", count: 4 },
  { name: "TOILETTER I HALLEN", count: 3 }, 
  { name: "TOILETTER PÅ DEN LANGE GANG", count: 2 }, 
  { name: "GANGEN VED TG OG KOMPO", count: 1 },
  { name: "GYMNASTIKSALEN", count: 2 },
  { name: "HALLEN", count: 2 },
];

const FIXED_TASKS = [
  { id: 'f1', label: 'Fredag: Aftensmad (Før)', day: 'Fredag', count: 2 },
  { id: 'f2', label: 'Fredag: Aftensmad (Efter)', day: 'Fredag', count: 2 },
  { id: 'f3', label: 'Fredag: Aftenservering', day: 'Fredag', count: 2 },
  { id: 'l1', label: 'Lørdag: Mokost (Før)', day: 'Lørdag', count: 2 },
  { id: 'l2', label: 'Lørdag: Mokost (Efter)', day: 'Lørdag', count: 2 },
  { id: 'l3', label: 'Lørdag: Aftensmad (Før)', day: 'Lørdag', count: 2 },
  { id: 'l4', label: 'Lørdag: Aftensmad (Efter)', day: 'Lørdag', count: 2 },
  { id: 'l5', label: 'Lørdag: Eftermiddagsservering', day: 'Lørdag', count: 2 },
  { id: 'l6', label: 'Lørdag: Aftenservering', day: 'Lørdag', count: 2 },
  { id: 's1', label: 'Søndag: Mokost (Før)', day: 'Søndag', count: 2 },
  { id: 's2', label: 'Søndag: Mokost (Efter)', day: 'Søndag', count: 2 },
  { id: 's3', label: 'Søndag: Aftensmad (Før)', day: 'Søndag', count: 2 },
  { id: 's4', label: 'Søndag: Aftensmad (Efter)', day: 'Søndag', count: 2 },
  { id: 's5', label: 'Søndag: Eftermiddagsservering', day: 'Søndag', count: 2 },
  { id: 's6', label: 'Søndag: Aftenservering', day: 'Søndag', count: 2 }
];

const FIXED_SLEEP_AREAS = ["Teltet", "Shelteret", "Gymnastiksalen", "Medie", "Biografen", "Dagligstuen"];
const STORAGE_KEY = 'weekend_app_v106_final';
const WISE_COLORS = ['bg-[#FFB300]', 'bg-[#00BFA5]', 'bg-[#D81B60]', 'bg-[#1E88E5]', 'bg-[#5E35B1]'];
const TABS = ['import', 'students', 'rounds', 'tasks', 'cleaning', 'print'];

const cleanValue = (val: any): string => (val === null || val === undefined) ? '' : String(val).trim();
const normalizeHouse = (h: string) => {
  const s = String(h || '').split(' (')[0].split(',')[0].trim().toUpperCase();
  return s || 'UKENDT GANG';
};

// --- LOGIK: DYNAMISK NEDSKALERING AF KRAV (VED FOR FÅ ELEVER) ---
// Regler (jf. din beskrivelse):
// - Opgave med krav 1: bliver 1
// - Opgave med krav 2: kan drosles ned til 1
// - Opgave med krav >=3: kan skæres ned til 2 (og kun hvis det stadig ikke rækker: ned til 1)
// Låsning (område-lås): Hvis læreren låser et område, respekteres den aktuelle bemanding (0 eller flere).
type CountItem = {
  key: string;
  base: number;
  locked: boolean;
  currentAssigned: number;
};

const computeAdjustedCounts = (items: CountItem[], eligibleTotal: number): Record<string, number> => {
  // Basis-krav:
  // - Låste områder: "krav" = det, der allerede er valgt (0..n) (lærer-override).
  // - Ulåste områder: "krav" = base.
  const counts: Record<string, number> = {};
  items.forEach(it => {
    counts[it.key] = it.locked ? it.currentAssigned : it.base;
  });

  const sum = () => Object.values(counts).reduce((a, b) => a + b, 0);
  let needReduce = sum() - Math.max(0, eligibleTotal);
  if (needReduce <= 0) return counts;

  // Kun ulåste områder kan nedskaleres.
  const unlocked = items.filter(it => !it.locked);

  // Hjælper: foretrukken minimumsgrænse.
  // - base 1: kan ikke nedskaleres (min=1)
  // - base 2: kan ned til 1
  // - base >=3: bør ned til 2 (men kan i nødstilfælde ned til 1)
  const preferredFloor = (base: number) => (base === 1 ? 1 : base === 2 ? 1 : 2);
  const emergencyFloor = (_base: number) => 1; // absolut bund (0 kun via lærer-låsning)

  // HIERARKI / PRIORITERING:
  // Reducér altid de "små" opgaver først, så det bliver relativt:
  // Hvis en stor opgave bliver nedskaleret, skal mindre opgaver allerede være nedskaleret.
  const byBaseAsc = [...unlocked].sort((a, b) => a.base - b.base);

  // Pass 1: Ned til foretrukken bund (1/1/2) med små opgaver først.
  for (const it of byBaseAsc) {
    if (needReduce <= 0) break;
    const k = it.key;
    const floor = preferredFloor(it.base);
    while (needReduce > 0 && counts[k] > floor) {
      counts[k] -= 1;
      needReduce -= 1;
    }
  }

  // Pass 2 (nødbremse): Hvis der stadig mangler, tillad 2->1 (kun relevant for base>=3),
  // igen med små "store" opgaver først, så de allerstørste prioriteres højest.
  if (needReduce > 0) {
    for (const it of byBaseAsc) {
      if (needReduce <= 0) break;
      const k = it.key;
      const floor = emergencyFloor(it.base);
      while (needReduce > 0 && counts[k] > floor) {
        counts[k] -= 1;
        needReduce -= 1;
      }
    }
  }

  return counts;
};

// --- KOMPONENT: AREACARD ---

// --- DÆKNINGSSTATUS (RØD/GUL/GRØN) ---
// Bruges til at give læreren overblik, når der mangler elever.
type CoverageTone = 'red' | 'yellow' | 'green' | 'none';

const coverageStatus = (assigned: number, required: number): { tone: CoverageTone; label: string } => {
  if (required <= 0) return { tone: 'none', label: `${assigned}/0` };
  if (assigned <= 0) return { tone: 'red', label: `0/${required}` };
  if (assigned < required) return { tone: 'yellow', label: `${assigned}/${required}` };
  return { tone: 'green', label: `${assigned}/${required}` };
};

const coverageClass = (tone: CoverageTone) => {
  // Matcher appens farver: pink/rød, gul, grøn (teal)
  switch (tone) {
    case 'red': return 'bg-[#D81B60]/30 border-2 border-[#D81B60]/60';
    case 'yellow': return 'bg-[#FFB300]/26 border-2 border-[#FFB300]/60';
    case 'green': return 'bg-[#00BFA5]/22 border-2 border-[#00BFA5]/60';
    default: return 'bg-white/5 border border-white/10';
  }
};


const coveragePriority = (tone: CoverageTone) => {
  // Lavere = vigtigere (øverst)
  switch (tone) {
    case 'red': return 0;
    case 'yellow': return 1;
    case 'green': return 2;
    default: return 3;
  }
};


const coveragePriorityDonor = (tone: CoverageTone) => {
  // Lavere = bedre donor (øverst) – steder med 'green' er lettest at flytte FRA
  switch (tone) {
    case 'green': return 0;
    case 'yellow': return 1;
    case 'red': return 2;
    default: return 3;
  }
};

interface AreaCardProps {
  id: string;
  label: string;
  studentsInArea: string[];
  type: 'rounds' | 'tasks' | 'cleaning';
  idx: number;
  students: any[];
  brandListDay: string;
  checkedMap: Record<string, boolean>;
  setCheckedMap: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  lockedAreas: Record<string, boolean>;
  setLockedAreas: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  expandedCards: Record<string, boolean>;
  setExpandedCards: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  isGlobalLocked: boolean;
  setEditTarget: (v: any) => void;
  pulseMarks?: Record<string, number>;

  // Used to highlight students with multiple assignments (across tasks + cleaning)
  taskCountByStudent: Record<string, number>;
  cleaningCountByStudent: Record<string, number>;
  taskAssignments: Record<string, string[]>;
  cleaningAssignments: Record<string, string[]>;
}

const AreaCard: React.FC<AreaCardProps> = ({ 
  id, label, studentsInArea, type, idx, 
  students, brandListDay, 
  checkedMap, setCheckedMap, lockedAreas, setLockedAreas, 
  expandedCards, setExpandedCards, isGlobalLocked, setEditTarget,
  taskCountByStudent, cleaningCountByStudent, taskAssignments, cleaningAssignments,
  pulseMarks
}) => {
  const [localSearch, setLocalSearch] = useState('');

  const sortedIds = useMemo(() => {
    let data = studentsInArea.map(sid => students.find(s => s.id === sid)).filter(Boolean) as any[];
    if (id === 'pool' && localSearch) {
      data = data.filter(s => `${s.firstName} ${s.lastName}`.toLowerCase().includes(localSearch.toLowerCase()));
    }
    if (type === 'rounds') {
      return data.sort((a, b) => {
        const roomA = (a.sleepingLocations?.[brandListDay] || `${a.house} - ${a.room}`).split(' - ')[1] || '0';
        const roomB = (b.sleepingLocations?.[brandListDay] || `${b.house} - ${b.room}`).split(' - ')[1] || '0';
        const roomComp = roomA.localeCompare(roomB, undefined, { numeric: true });
        return roomComp !== 0 ? roomComp : a.firstName.localeCompare(b.firstName);
      }).map(s => s.id);
    } else {
      return data.sort((a, b) => a.firstName.localeCompare(b.firstName)).map(s => s.id);
    }
  }, [studentsInArea, type, brandListDay, id, localSearch, students]);

  const markedCount = studentsInArea.filter(sid => checkedMap[sid]).length;
  const isFullyMarked = studentsInArea.length > 0 && markedCount === studentsInArea.length;
  const isExp = expandedCards[`${type}-${id}`];
  const isPulsing = !!pulseMarks?.[`${type}-${id}`];
  const isAreaLocked = lockedAreas[`${type}-${id}`];

  return (
    <div className={`bg-white/5 rounded-[2.5rem] border transition-all duration-300 overflow-hidden shadow-xl ${isFullyMarked ? 'border-[#00BFA5] ring-2 ring-[#00BFA5]/20' : 'border-white/10'}`}>
      <div className="p-7 flex justify-between items-center">
        <div className="flex items-center gap-5 cursor-pointer flex-1" onClick={() => setExpandedCards(p => ({...p, [`${type}-${id}`]: !isExp}))}>
          <div 
            onClick={(e) => { e.stopPropagation(); setLockedAreas(p => ({...p, [`${type}-${id}`]: !isAreaLocked})); }}
            className={`relative ${isAreaLocked ? 'bg-red-500 text-white' : WISE_COLORS[idx % 5] + ' text-black'} w-12 h-12 rounded-2xl flex flex-col items-center justify-center font-black shrink-0 transition-colors`}
          >
            {isFullyMarked ? <CheckCircle2 className="w-7 h-7 stroke-[2.5]"/> : <span className="text-[14px]">{markedCount}/{studentsInArea.length}</span>}
            {isAreaLocked && <Lock className="w-3 h-3 absolute -top-1 -right-1 bg-black rounded-full p-0.5 text-white"/>}
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
            <span className="font-black uppercase tracking-widest text-xs italic">{label}</span>
            {isPulsing && <RotateCcw className="w-4 h-4 text-white/70 animate-spin" style={{animationDuration:'700ms'}}/>}
          </div>
            {id === 'pool' && <span className="text-[8px] opacity-40 uppercase tracking-widest">{type === 'cleaning' ? 'På egen gang' : 'Ikke tildelt'}</span>}
          </div>
        </div>
        <ChevronDown onClick={() => setExpandedCards(p => ({...p, [`${type}-${id}`]: !isExp}))} className={`transition-transform duration-300 ${isExp ? 'rotate-180' : ''} opacity-20 cursor-pointer`}/>
      </div>
      {isExp && (
        <div className="p-3 border-t border-white/5 space-y-2 bg-black/20">
          {id === 'pool' && (
            <div className="px-3 pb-4 pt-1">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 opacity-20"/>
                <input 
                  type="text" 
                  placeholder="Søg i puljen..." 
                  value={localSearch} 
                  onChange={e => setLocalSearch(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 p-5 pl-12 rounded-2xl outline-none text-sm focus:border-[#FFB300] transition-all"
                />
              </div>
            </div>
          )}
          {sortedIds.map(sid => {
            const s = students.find(x => x.id === sid);
            if (!s) return null;
            const defaultLoc = `${s.house} - ${s.room}`;
            const loc = s.sleepingLocations?.[brandListDay] || defaultLoc;
            const isMoved = loc !== defaultLoc;
            const roomDisplay = loc.includes(' - ') ? loc.split(' - ')[1] : 'Fælles';

            // Multi-assign awareness (across tasks + cleaning)
            const taskN = taskCountByStudent[sid] || 0;
            const cleanN = cleaningCountByStudent[sid] || 0;
            const extraTotal = Math.max(0, taskN - 1) + Math.max(0, cleanN - 1);
            const hasExtra = extraTotal > 0;
            const studentTasks = FIXED_TASKS.filter(t => (taskAssignments[t.id] || []).includes(sid)).map(t => t.label);
            const studentCleaning = FIXED_CLEANING.filter(a => (cleaningAssignments[a.name] || []).includes(sid)).map(a => a.name);
            const mapTitle = hasExtra
              ? `Ekstra opgaver (+${extraTotal})\nMadtjanser: ${studentTasks.join(' • ') || '—'}\nFællesområder: ${studentCleaning.join(' • ') || '—'}`
              : `Madtjanser: ${studentTasks.join(' • ') || '—'}\nFællesområder: ${studentCleaning.join(' • ') || '—'}`;
            return (
              <div key={sid} className={`p-5 rounded-2xl flex justify-between items-center transition-all ${isMoved && type === 'rounds' ? 'bg-[#FFB300]/10 border border-[#FFB300]/40 ring-1 ring-[#FFB300]/20 shadow-[0_0_15px_rgba(255,179,0,0.1)]' : 'bg-white/10'}`}>
                <div className="flex-1 flex items-center gap-4">
                  <button disabled={isGlobalLocked} onClick={() => setCheckedMap(p => ({...p, [sid]: !checkedMap[sid]}))} className={`w-10 h-10 rounded-full border-2 flex items-center justify-center transition-all ${checkedMap[sid] ? 'bg-[#00BFA5] border-[#00BFA5] text-black' : 'border-white/10 text-transparent'}`}><Check className="w-5 h-5"/></button>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-black text-lg leading-tight">{s.firstName} <span className="text-xs opacity-30 font-normal">{s.lastName}</span></p>
                      {isMoved && type === 'rounds' && <span className="bg-[#FFB300] text-black text-[7px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter shadow-sm animate-pulse">Flyttet</span>}
                    </div>
                    <p className="text-[10px] font-black uppercase opacity-40">{type === 'rounds' ? `Værelse: ${roomDisplay}` : `${s.house} • ${s.room}`}</p>
                  </div>
                </div>
                <button
                  disabled={isGlobalLocked}
                  onClick={() => setEditTarget({sid, type})}
                  title={mapTitle}
                  className={`p-4 rounded-2xl shadow-lg active:scale-90 transition-transform border ${hasExtra ? 'bg-[#D81B60]/25 border-[#D81B60]/60 ring-1 ring-[#D81B60]/25' : 'bg-white/5 border-white/10'}`}
                >
                  <MapPin className={`w-5 h-5 ${hasExtra ? 'text-[#D81B60]' : ''}`}/>
                </button>
              </div>
            );
          })}
          {sortedIds.length === 0 && <p className="p-8 text-center text-[10px] uppercase opacity-20 italic">Ingen fundet</p>}
        </div>
      )}
    </div>
  );
};

// --- HOVED APP ---
const App = () => {
  const [students, setStudents] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState('import');
  const [weekendNum, setWeekendNum] = useState(getISOWeek());
  const [weekendName, setWeekendName] = useState('');
  const [taskAssignments, setTaskAssignments] = useState<Record<string, string[]>>({});
  const [cleaningAssignments, setCleaningAssignments] = useState<Record<string, string[]>>({});

  // Micro-feedback when auto-distribution runs (show a short ↻ spin on affected cards)
  const [pulseMarks, setPulseMarks] = useState<Record<string, number>>({});
  const triggerPulse = (keys: string[]) => {
    const runId = Date.now();
    setPulseMarks(prev => {
      const next = { ...prev };
      keys.forEach(k => { next[k] = runId; });
      return next;
    });
    window.setTimeout(() => {
      setPulseMarks(prev => {
        const next = { ...prev };
        keys.forEach(k => { if (next[k] === runId) delete next[k]; });
        return next;
      });
    }, 900);
  };


  // Counts used for "+N" badges on elevkort (multi-assign visibility)
  const taskCountByStudent = useMemo(() => {
    const m: Record<string, number> = {};
    Object.values(taskAssignments).forEach(ids => {
      (ids || []).forEach(id => { m[id] = (m[id] || 0) + 1; });
    });
    return m;
  }, [taskAssignments]);

  const cleaningCountByStudent = useMemo(() => {
    const m: Record<string, number> = {};
    Object.values(cleaningAssignments).forEach(ids => {
      (ids || []).forEach(id => { m[id] = (m[id] || 0) + 1; });
    });
    return m;
  }, [cleaningAssignments]);

  const getStudentAssignments = (sid: string) => {
    const tasks = FIXED_TASKS.filter(t => (taskAssignments[t.id] || []).includes(sid)).map(t => t.label);
    const cleaning = FIXED_CLEANING.filter(a => (cleaningAssignments[a.name] || []).includes(sid)).map(a => a.name);
    const taskN = tasks.length;
    const cleanN = cleaning.length;
    const extraTotal = Math.max(0, taskN - 1) + Math.max(0, cleanN - 1);
    return { tasks, cleaning, taskN, cleanN, extraTotal };
  };

  const [lockedAreas, setLockedAreas] = useState<Record<string, boolean>>({});
  const [isGlobalLocked, setIsGlobalLocked] = useState(false);
  const [previewType, setPreviewType] = useState<string | null>(null);

  const WEEKENDPLAN_PHOTO_KEY = 'hu_weekendplan_photo_v1';
  const [weekendplanPhoto, setWeekendplanPhoto] = useState<string>('');
  const photoInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(WEEKENDPLAN_PHOTO_KEY);
      if (saved) setWeekendplanPhoto(saved);
    } catch {}
  }, []);

  const handlePickWeekendplanPhoto = () => {
    photoInputRef.current?.click();
  };

  const handleWeekendplanPhotoFile: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Keep it lightweight: resize/compress would be nice, but we keep it simple (dataURL).
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || '');
      setWeekendplanPhoto(dataUrl);
      try { localStorage.setItem(WEEKENDPLAN_PHOTO_KEY, dataUrl); } catch {}
    };
    reader.readAsDataURL(file);

    // allow picking same file again
    e.currentTarget.value = '';
  };

  const handleDeleteWeekendplanPhoto = () => {
    setWeekendplanPhoto('');
    try { localStorage.removeItem(WEEKENDPLAN_PHOTO_KEY); } catch {}
  };
  const [searchTerm, setSearchTerm] = useState('');
  const [showAllStudents, setShowAllStudents] = useState(false);
  const [brandListDay, setBrandListDay] = useState<'Fredag' | 'Lørdag' | 'Søndag'>('Fredag');
  const [expandedCards, setExpandedCards] = useState<Record<string, boolean>>({});
  const [editTarget, setEditTarget] = useState<{sid: string, type: 'rounds' | 'tasks' | 'cleaning'} | null>(null);
  const [assignMode, setAssignMode] = useState<'move' | 'add'>('move');
  useEffect(() => {
    // Reset to safe default when opening a new picker
    if (editTarget) setAssignMode('move');
  }, [editTarget]);
  const [showInfo, setShowInfo] = useState(false);
  
  const [selectedMoveHouse, setSelectedMoveHouse] = useState<string | null>(null);
  const [printTasks, setPrintTasks] = useState(true);
  const [printCleaning, setPrintCleaning] = useState(true);
  const [printWeekendPlan, setPrintWeekendPlan] = useState(true);
  const [sundayShowCrosses, setSundayShowCrosses] = useState(true);
  
  const [checkedRounds, setCheckedRounds] = useState<Record<string, boolean>>({});
  const [checkedTasks, setCheckedTasks] = useState<Record<string, boolean>>({});
  const [checkedCleaning, setCheckedCleaning] = useState<Record<string, boolean>>({});

  // Makes auto-distribution visibly change between clicks (rotation across eligible students)
  const autoCleanNonceRef = useRef(0);

  const touchStart = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);

  
  // Sortér så røde/gule (mangler) kommer øverst – giver hurtigt overblik
  const tasksForPicker = useMemo(() => {
    return [...FIXED_TASKS].sort((a, b) => {
      const aAssigned = (taskAssignments[a.id] || []).length;
      const bAssigned = (taskAssignments[b.id] || []).length;
      const aTone = coverageStatus(aAssigned, a.count).tone;
      const bTone = coverageStatus(bAssigned, b.count).tone;
      const d = coveragePriority(aTone) - coveragePriority(bTone);
      if (d !== 0) return d;
      return a.label.localeCompare(b.label, 'da');
    });
  }, [taskAssignments]);

  const cleaningAreasForPicker = useMemo(() => {
    // I vælgeren: vis behov først (rød/gul øverst) så læreren ser hvor der mangler
    return [...FIXED_CLEANING].sort((a, b) => {
      const aAssigned = (cleaningAssignments[a.name] || []).length;
      const bAssigned = (cleaningAssignments[b.name] || []).length;
      const aTone = coverageStatus(aAssigned, a.count).tone;
      const bTone = coverageStatus(bAssigned, b.count).tone;
      const d = coveragePriority(aTone) - coveragePriority(bTone);
      if (d !== 0) return d;
      return a.name.localeCompare(b.name, 'da');
    });
  }, [cleaningAssignments]);

  const cleaningAreasForOverview = useMemo(() => {
    // På forsiden for rengøring kan det give mening at vise "donorer" øverst,
    // hvis der ER mangler (så man hurtigt kan finde steder at flytte FRA).
    const base = [...FIXED_CLEANING];
    const anyNeed = base.some(a => {
      const assigned = (cleaningAssignments[a.name] || []).length;
      const tone = coverageStatus(assigned, a.count).tone;
      return tone === 'red' || tone === 'yellow';
    });

    if (!anyNeed) {
      // Ellers: bare alfabetisk
      return base.sort((a, b) => a.name.localeCompare(b.name, 'da'));
    }

    // Mangler findes: donor-først (green -> yellow -> red), derefter alfabetisk
    return base.sort((a, b) => {
      const aAssigned = (cleaningAssignments[a.name] || []).length;
      const bAssigned = (cleaningAssignments[b.name] || []).length;
      const aTone = coverageStatus(aAssigned, a.count).tone;
      const bTone = coverageStatus(bAssigned, b.count).tone;
      const d = coveragePriorityDonor(aTone) - coveragePriorityDonor(bTone);
      if (d !== 0) return d;
      return a.name.localeCompare(b.name, 'da');
    });
  }, [cleaningAssignments]);

useEffect(() => { setSelectedMoveHouse(null); }, [editTarget]);

  // --- PERSISTENS ---
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const p = JSON.parse(saved) as any;
        if (p.students) setStudents(p.students);
        if (p.weekendNum) setWeekendNum(p.weekendNum);
        if (p.weekendName) setWeekendName(p.weekendName);
        if (p.isGlobalLocked !== undefined) setIsGlobalLocked(p.isGlobalLocked);
        if (p.taskAssignments) setTaskAssignments(p.taskAssignments);
        if (p.cleaningAssignments) {
          const next: Record<string, string[]> = {};
          for (const area of FIXED_CLEANING) {
            const k = area.name;
            if (p.cleaningAssignments[k]) next[k] = p.cleaningAssignments[k];
          }
          setCleaningAssignments(next);
        }
        if (p.lockedAreas) setLockedAreas(p.lockedAreas);
        if (p.checkedRounds) setCheckedRounds(p.checkedRounds);
        if (p.checkedTasks) setCheckedTasks(p.checkedTasks);
        if (p.checkedCleaning) setCheckedCleaning(p.checkedCleaning);
      } catch (e) { console.error("Load error", e); }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ 
      students, weekendNum, weekendName, taskAssignments, cleaningAssignments, lockedAreas,
      isGlobalLocked, checkedRounds, checkedTasks, checkedCleaning 
    }));
  }, [students, weekendNum, weekendName, taskAssignments, cleaningAssignments, lockedAreas, isGlobalLocked, checkedRounds, checkedTasks, checkedCleaning]);

  // --- SHAKE TO SHUFFLE LOGIK ---
  useEffect(() => {
    let lastUpdate = 0;
    let x: number = 0, y: number = 0, z: number = 0;
    let lastX: number = 0, lastY: number = 0, lastZ: number = 0;
    const threshold = 15;

    const handleMotion = (event: DeviceMotionEvent) => {
      const acc = event.accelerationIncludingGravity;
      if (!acc) return;
      const curTime = new Date().getTime();
      if ((curTime - lastUpdate) > 100) {
        const diffTime = curTime - lastUpdate;
        lastUpdate = curTime;
        x = acc.x || 0; 
        y = acc.y || 0; 
        z = acc.z || 0;
        const speed = Math.abs(x + (y || 0) + (z || 0) - (lastX || 0) - (lastY || 0) - (lastZ || 0)) / diffTime * 10000;
        if (speed > threshold * 100) {
          if ((activeTab === 'tasks' || activeTab === 'cleaning') && !isGlobalLocked) {
             performAuto(activeTab as 'tasks' | 'cleaning');
             if (window.navigator.vibrate) window.navigator.vibrate(200);
          }
        }
        lastX = x; lastY = y; lastZ = z;
      }
    };

    window.addEventListener('devicemotion', handleMotion);
    return () => window.removeEventListener('devicemotion', handleMotion);
  }, [activeTab, isGlobalLocked, students, taskAssignments, cleaningAssignments]);

  const requestMotionPermission = () => {
    if (typeof (DeviceMotionEvent as any).requestPermission === 'function') {
      (DeviceMotionEvent as any).requestPermission().then((p: string) => {
        if (p === 'granted') {
           if (!isGlobalLocked) performAuto(activeTab as any);
        }
      });
    } else {
      if (!isGlobalLocked) performAuto(activeTab as any);
    }
  };

  const loadDemoData = () => {
    const firstNames = ["Finn", "Olga", "Ib", "Gertrud", "Mogens", "Ulla", "Bent", "Berta", "Gudrun", "Sif", "Palle", "Yrsa", "Holger", "Tove", "Preben", "Lisbeth", "Flemming", "Kirsten", "Viggo", "Agnes", "Sigurd", "Dagmar", "Knud", "Rigmor", "Svante"];
    const lastNames = ["Flødeskum", "Ostehaps", "Ildpuster", "Gulerod", "Mælkebøtte", "Underhylere", "Blyant", "Brandhane", "Gummistøvle", "Sukkervand", "Pølsegift", "Kaffegrums", "Musetrap", "Tandpasta", "Lakridsbånd", "Skraldespand", "Sovesofa", "Kaffekande", "Cykelhjelm", "Bukseben", "Skægstub", "Næsehorn", "Papkasse", "Saltstang"];
    const houses = ["Hjemstavn", "Gimle", "Mellemtiden", "Øst", "Vest", "Nord", "Syd", "Komponisten", "Tankegangen"];
    
    const demoStudents = [];
    for (let i = 0; i < 150; i++) {
        const fn = firstNames[Math.floor(Math.random() * firstNames.length)];
        const ln = lastNames[Math.floor(Math.random() * lastNames.length)];
        const house = houses[i % houses.length];
        const room = Math.floor(i / houses.length) + 1;
        demoStudents.push({
            id: `demo-${i}`,
            firstName: fn,
            lastName: ln,
            house: house.toUpperCase(),
            room: String(room),
            isPresent: Math.random() > 0.1,
            isKitchenDuty: false,
            sleepingLocations: {
                'Fredag': `${house.toUpperCase()} - ${room}`,
                'Lørdag': `${house.toUpperCase()} - ${room}`,
                'Søndag': `${house.toUpperCase()} - ${room}`
            }
        });
    }
    setStudents(demoStudents);
    setIsGlobalLocked(true);
    setActiveTab('students');
  };

  // --- SWIPE LOGIK ---
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStart.current = e.targetTouches[0].clientX;
    touchStartY.current = e.targetTouches[0].clientY;
  };
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStart.current === null || touchStartY.current === null || previewType) return;
    const touchEnd = e.changedTouches[0].clientX;
    const touchEndY = e.changedTouches[0].clientY;
    const diff = touchStart.current - touchEnd;
    const diffY = touchStartY.current - touchEndY;
    const currentIdx = TABS.indexOf(activeTab);

    if (diffY < -150 && Math.abs(diff) < 50) {
      setActiveTab('import');
    }
    else if (Math.abs(diff) > 70 && Math.abs(diffY) < 100) {
      if (diff > 0 && currentIdx < TABS.length - 1) setActiveTab(TABS[currentIdx + 1]);
      if (diff < 0 && currentIdx > 0) setActiveTab(TABS[currentIdx - 1]);
    }
    touchStart.current = null;
    touchStartY.current = null;
  };

  // --- LOGIK: UDELUKKELSE FRA RENGØRING ---
  const mokostExcludedIds = useMemo(() => {
    const l2 = taskAssignments['l2'] || [];
    const s2 = taskAssignments['s2'] || [];
    return new Set([...l2, ...s2]);
  }, [taskAssignments]);

  // --- DYNAMISK KRAV (hvis for få tilmeldte til at fylde alt ud) ---
  const eligibleTaskCount = useMemo(() => {
    // Alle tilstede, som ikke er køkkenhold (køkkenholdet bruges ikke til tjanser her)
    return students.filter(s => s.isPresent && !s.isKitchenDuty).length;
  }, [students]);

  const eligibleCleaningCount = useMemo(() => {
    // Rengøring: samme som ovenfor, men excl. Mokost-efter (l2+s2) som ikke må indgå i rengøring.
    return students.filter(s => s.isPresent && !s.isKitchenDuty && !mokostExcludedIds.has(s.id)).length;
  }, [students, mokostExcludedIds]);

  const adjustedTaskCounts = useMemo(() => {
    const items: CountItem[] = FIXED_TASKS.map(t => ({
      key: t.id,
      base: t.count,
      locked: !!lockedAreas[`tasks-${t.id}`],
      currentAssigned: (taskAssignments[t.id] || []).length
    }));
    return computeAdjustedCounts(items, eligibleTaskCount);
  }, [eligibleTaskCount, lockedAreas, taskAssignments]);

  const adjustedCleaningCounts = useMemo(() => {
    const items: CountItem[] = FIXED_CLEANING.map(a => ({
      key: a.name,
      base: a.count,
      locked: !!lockedAreas[`cleaning-${a.name}`],
      currentAssigned: (cleaningAssignments[a.name] || []).length
    }));
    return computeAdjustedCounts(items, eligibleCleaningCount);
  }, [eligibleCleaningCount, lockedAreas, cleaningAssignments]);

  // --- AUTO FORDELING ---
  const performAuto = (type: 'tasks' | 'cleaning') => {
    if (isGlobalLocked) return;

    // Each run gets a new nonce so selection rotates between clicks (esp. when a group has > needed)
    const runNonce = type === 'cleaning' ? (autoCleanNonceRef.current = (autoCleanNonceRef.current + 1)) : 0;
    const checkedMap = type === 'tasks' ? checkedTasks : checkedCleaning;
    const assignments = type === 'tasks' ? taskAssignments : cleaningAssignments;
    const lockedStudentIds = new Set<string>();
    students.forEach((s: any) => { if (checkedMap[s.id as string]) lockedStudentIds.add(s.id); });

    const newAssignments: Record<string, string[]> = {};
    Object.entries(assignments).forEach(([areaId, sids]) => {
      const ids = sids as string[];
      const lockedInArea = ids.filter(sid => lockedStudentIds.has(sid) || lockedAreas[`${type}-${areaId}`]);
      newAssignments[areaId] = lockedInArea;
      lockedInArea.forEach(sid => lockedStudentIds.add(sid));
    });

    const pool = students
      .filter(s => {
        // Cleaning: we allow everyone who is present and not already locked.
        // (Teachers can still manually adjust; strict group rules are enforced below.)
        return s.isPresent && !s.isKitchenDuty && !lockedStudentIds.has(s.id) && (type !== 'cleaning' || !mokostExcludedIds.has(s.id));
      })
      // Shuffle to avoid always picking the same students. Still ok to be random, but the
      // additional rotation below ensures visible change even with stable ordering.
      .sort(() => Math.random() - 0.5);

    if (type === 'tasks') {
      FIXED_TASKS.forEach(t => {
        if (lockedAreas[`tasks-${t.id}`]) return;
        const currentCount = (newAssignments[t.id] || []).length;
        const target = t.count;
        const needed = target - currentCount;
        if (needed > 0) {
          const extra = pool.splice(0, needed);
          newAssignments[t.id] = [...(newAssignments[t.id] || []), ...extra.map(s => s.id)];
        }
      });
            setTaskAssignments(newAssignments);
      triggerPulse([...FIXED_TASKS.map(t => `tasks-${t.id}`), 'tasks-pool']);
    } else {
      // Hjælper: stabil hash til at variere rotation pr. område
      const hashStr = (s: string) => {
        let h = 0;
        for (let i = 0; i < s.length; i++) h = ((h << 5) - h) + s.charCodeAt(i);
        return Math.abs(h);
      };

      // Hjælper: træk N elever ud af poolen som matcher en betingelse (og fjern dem fra poolen)
      // Med rotation så klik på terningen tydeligt giver en ny fordeling (round-robin-ish).
      const takeFromPool = (pred: (s:any)=>boolean, n: number, salt: string) => {
        const matches = pool.filter(pred);
        if (matches.length === 0 || n <= 0) return [] as any[];
        const offset = (runNonce + hashStr(salt)) % matches.length;
        const rotated = [...matches.slice(offset), ...matches.slice(0, offset)];
        const picked = rotated.slice(0, n);

        // remove picked from pool
        picked.forEach(p => {
          const idx = pool.findIndex(x => x.id === p.id);
          if (idx > -1) pool.splice(idx, 1);
        });
        return picked;
      };

      const HOUSE = (h:any) => String(h || '').toUpperCase();

      // VIGTIGT: Prioritér de områder med særlige regler, så andre opgaver ikke “stjæler” de relevante elever først.
      // Rækkefølge:
      //  1) GANGEN VED TG OG KOMPO (kun Tankegangen/Komponisten – ingen fallback)
      //  2) GANGENE I TREENIGHEDEN (kun Poeten/Gimle/Mellemtiden – ingen fallback)
      //  3) KLASSEFLØJEN + TOILETTER (kun Hjemstavn, og kun hvis der mangler Hjemstavn -> må andre bruges)
      //  4) resten i den originale rækkefølge
      const areaPriority = (name: string) => {
        const n = HOUSE(name);
        if (n === 'GANGEN VED TG OG KOMPO') return 0;
        if (n === 'GANGENE I TREENIGHEDEN') return 1;
        if (n === 'KLASSEFLØJEN + TOILETTER') return 2;
        return 3;
      };

      const cleaningAreasOrdered = [...FIXED_CLEANING].sort((a, b) => {
        const pa = areaPriority(a.name);
        const pb = areaPriority(b.name);
        if (pa !== pb) return pa - pb;
        // behold stabil, men fall back til original label sort for determinisme
        return a.name.localeCompare(b.name, 'da');
      });

      cleaningAreasOrdered.forEach(area => {
        if (lockedAreas[`cleaning-${area.name}`]) return;

        const currentCount = (newAssignments[area.name] || []).length;
        const target = area.count;
        let needed = target - currentCount;
        if (needed <= 0) return;

        let picked: any[] = [];

        if (HOUSE(area.name) === 'GANGEN VED TG OG KOMPO') {
          const allowed = new Set(['TANKEGANGEN', 'KOMPONISTEN']);
          picked = takeFromPool((s:any) => allowed.has(HOUSE(s.house)), needed, area.name);
          // ingen fallback
        } else if (HOUSE(area.name) === 'GANGENE I TREENIGHEDEN') {
          const allowed = new Set(['POETEN', 'GIMLE', 'MELLEMTIDEN']);
          picked = takeFromPool((s:any) => allowed.has(HOUSE(s.house)), needed, area.name);
          // ingen fallback
        } else if (HOUSE(area.name) === 'KLASSEFLØJEN + TOILETTER') {
          // STRICT: KUN Hjemstavn. Ingen fallback. Hvis der ikke er nok, bliver resten tomt.
          picked = takeFromPool((s:any) => HOUSE(s.house) === 'HJEMSTAVN', needed, area.name);
        } else {
          picked = takeFromPool(() => true, needed, area.name);
        }

        if (picked.length > 0) {
          newAssignments[area.name] = [...(newAssignments[area.name] || []), ...picked.map(s => s.id)];
        }
      });
      const houses = Array.from(new Set(students.map(s => String(s.house))));
      houses.forEach(h => {
        const houseKey = h as string;
        if (lockedAreas[`${type}-${houseKey}`]) return;
        const houseStudents = pool.filter(s => s.house === houseKey).map(s => s.id);
        newAssignments[houseKey] = [...(newAssignments[houseKey] || []), ...houseStudents];
        houseStudents.forEach(id => {
          const idx = pool.findIndex(p => p.id === id);
          if (idx > -1) pool.splice(idx, 1);
        });
      });
      setCleaningAssignments(newAssignments);
      triggerPulse(FIXED_CLEANING.map(a => `cleaning-${a.name}`));
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const res = ev.target?.result;
        if (typeof res !== 'string') return;
        const wb = XLSX.read(res, { type: 'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const data = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
        const headers = data[0].map(h => String(h || '').trim().toLowerCase());
        const findIdx = (names: string[]) => headers.findIndex(h => names.some(n => h.includes(n)));
        const idx = { 
          first: findIdx(['fornavn']), 
          last: findIdx(['efternavn']), 
          room: findIdx(['værelse', 'room']), 
          house: findIdx(['studenthouse', 'hus', 'gang', 'house']),
          where: findIdx(['hvor er du i weekenden', 'weekenden'])
        };
        const parsed = data.slice(1).filter(row => row[idx.first]).map((row, i) => {
          const house = normalizeHouse(cleanValue(row[idx.house]));
          const room = cleanValue(row[idx.room]) || '??';
          const whereVal = cleanValue(row[idx.where]).toLowerCase();
          const isPresent = whereVal.includes("hu hele") || whereVal.includes("hu indtil") || whereVal === "";
          return {
            id: `s-${Date.now()}-${i}`, 
            firstName: cleanValue(row[idx.first]),
            lastName: cleanValue(row[idx.last]), 
            room, 
            house, 
            isPresent,
            isKitchenDuty: false,
            sleepingLocations: { 
              'Fredag': `${house} - ${room}`, 
              'Lørdag': `${house} - ${room}`, 
              'Søndag': `${house} - ${room}` 
            }
          };
        });
        setStudents(parsed); setIsGlobalLocked(true); setActiveTab('students');
      } catch (err) { alert("Fejl i filen."); }
    };
    reader.readAsBinaryString(file);
  };

  const getName = (id: string) => { const s = students.find(x => x.id === id); return s ? `${s.firstName} ${s.lastName}` : '??'; };
  const getNamesFormatted = (ids: string[]) => ids && ids.length > 0 ? `${ids.map(getName).join(', ')}` : '??, ??';

  const stats = useMemo(() => ({
    present: students.filter(s => s.isPresent).length,
    kitchen: students.filter(s => s.isKitchenDuty && s.isPresent).length,
    total: students.length
  }), [students]);

  const groupedRounds = useMemo(() => {
    const groups: Record<string, string[]> = {};
    students.filter(s => s.isPresent).forEach(s => {
      const loc = (s.sleepingLocations && s.sleepingLocations[brandListDay]) || `${s.house} - ${s.room}`;
      const areaName = loc.includes(' - ') ? loc.split(' - ')[0] : loc;
      if (!groups[areaName]) groups[areaName] = [];
      groups[areaName].push(s.id);
    });
    return Object.entries(groups).sort((a,b) => a[0].localeCompare(b[0]));
  }, [students, brandListDay]);

  const targetStudent = useMemo(() => editTarget?.type === 'rounds' ? students.find(s => s.id === editTarget.sid) : null, [editTarget, students]);
  const availableRoomsOnSameHouse = useMemo(() => targetStudent ? Array.from(new Set(students.filter(x => x.house === targetStudent.house).map(x => x.room))).filter(r => r !== targetStudent.room).sort() : [], [targetStudent, students]);
  const roomsOnSelectedHouse = useMemo(() => selectedMoveHouse ? Array.from(new Set(students.filter(x => x.house === selectedMoveHouse).map(x => x.room))).sort() : [], [selectedMoveHouse, students]);
  const otherHouses = useMemo(() => targetStudent ? Array.from(new Set(students.map(x => x.house as string))).sort().filter(h => h !== targetStudent.house) : [], [targetStudent, students]);

  const handleMove = (
    sid: string,
    targetLoc: string,
    type: 'rounds' | 'tasks' | 'cleaning',
    mode: 'move' | 'add' = 'move'
  ) => {
    if (type === 'rounds') {
      setStudents(prev => prev.map(s => {
        if (s.id !== sid) return s;
        return {
          ...s,
          sleepingLocations: { ...(s.sleepingLocations || {}), [brandListDay]: targetLoc }
        };
      }));
    } else if (type === 'tasks' || type === 'cleaning') {
      const setter = type === 'tasks' ? setTaskAssignments : setCleaningAssignments;
      setter(prev => {
        const next: Record<string, string[]> = { ...prev };
        const effectiveMode: 'move' | 'add' = (targetLoc === 'pool') ? 'move' : mode;

        if (effectiveMode === 'move') {
          // Remove from all other places in this category
          Object.keys(next).forEach(k => {
            next[k] = (next[k] || []).filter(id => id !== sid);
          });
        }

        const addTo = (key: string) => {
          if (!next[key]) next[key] = [];
          if (!next[key].includes(sid)) next[key].push(sid);
        };

        if (targetLoc !== 'pool') {
          addTo(targetLoc);
        } else if (type === 'cleaning') {
          // Cleaning pool means: back to own gang
          const s = students.find(x => x.id === sid);
          if (s) addTo(s.house);
        }

        return next;
      });
    }
    setEditTarget(null);
  };

  const commonProps = {
    students,
    brandListDay,
    expandedCards,
    setExpandedCards,
    isGlobalLocked,
    setEditTarget,
    taskCountByStudent,
    cleaningCountByStudent,
    taskAssignments,
    cleaningAssignments,
    pulseMarks
  };

  const weekendLabel = useMemo(() => {
    const base = `Uge ${weekendNum}`;
    return weekendName ? `${weekendName} • ${base}` : base;
  }, [weekendNum, weekendName]);

  const buildBackupFilename = () => {
    const slug = (weekendName || 'Weekend')
      .trim()
      .replace(/[^a-z0-9]+/gi, '_')
      .replace(/^_+|_+$/g, '') || 'Weekend';
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const stamp = `${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
    return `${slug}_uge${weekendNum}_${stamp}.json`;
  };


  const EmptyState = ({ tab }: { tab: string }) => (
    <div className="py-20 px-10 text-center animate-in fade-in">
      <Users className="w-16 h-16 opacity-10 mx-auto mb-6"/>
      <h3 className="text-xl font-black uppercase italic mb-2">Ingen data</h3>
      <p className="text-sm opacity-40 mb-8">Importer en elevliste før du bruger {tab}.</p>
      <button onClick={() => setActiveTab('import')} className="px-8 py-4 bg-[#FFB300] text-black rounded-2xl font-black uppercase text-xs">Gå til Dashboard</button>
    </div>
  );

  // --- PRINT: WEEKENDPLAN (Chrome-stabil A4 landscape) ---
  const weekendplanPrintCss = `html,body{height:100%;}

    .wp-photo-wrap{margin-top:6mm; border:1px solid #e5e7eb; border-radius:10px; padding:6mm; display:flex; align-items:center; justify-content:center; flex:1 1 auto; min-height:28mm; overflow:hidden; break-inside:avoid;}
    .wp-photo{width:100%; height:100%; max-width:100%; max-height:100%; object-fit:contain;}

    @page { size: A4 landscape; margin: 8mm; }
    body { margin: 0; font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; font-size: 10.8px; color: #000; }
    h1 { margin: 0 0 5mm 0; text-align: center; font-weight: 900; font-size: 18px; letter-spacing: -0.02em; text-transform: uppercase; }
    .wp-grid{display:grid; grid-template-columns:1fr 1fr; gap:10mm; align-items:stretch; flex:1 1 auto; min-height:0;}
    .wp-day { break-inside: avoid; page-break-inside: avoid; margin: 0 0 5mm 0; }
    .wp-day h2 { margin: 0 0 2.5mm 0; font-weight: 900; font-size: 13px; text-transform: uppercase; font-style: italic; }
    .wp-list { margin-left: 0; padding-left: 0; }
    .wp-row { display: flex; align-items: baseline; gap: 10px; margin: 0 0 2.2mm 0; }
    .wp-row-mini { margin: 0 0 1.6mm 0; font-size: 11px; opacity: 0.95; }
    .wp-row-mini .wp-title { font-style: italic; font-weight: 400; }
    .wp-row-mini .wp-time { font-weight: 700; opacity: 0.85; }

    .wp-time { width: 52px; flex: 0 0 52px; font-weight: 900; }
    .wp-main { font-weight: 600; }
    .wp-sub { font-weight: 400; font-style: italic; opacity: 0.75; }
  
.print-weekendplan{font-family:Inter,Arial,sans-serif; padding:0; display:flex; flex-direction:column; height:100%;}
.wp-col{display:flex; flex-direction:column; gap:8mm; min-height:0;}
`;


  // --- PRINT: SØNDAGSLISTE (Chrome-stabil A4 landscape via iframe) ---
  const sundayListPrintCss = (columnCount: number) => `
    @page { size: A4 landscape; margin: 8mm; }
    body { margin: 0; font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; font-size: 11px; color: #000; }
    h1 { margin: 0 0 6mm 0; text-align: left; font-weight: 900; font-size: 26px; letter-spacing: -0.02em; text-transform: uppercase; font-style: italic; }
    .rule { border-bottom: 4px solid #000; margin: 0 0 6mm 0; }
    .list { column-count: ${columnCount}; column-gap: 10mm; }
    .item { break-inside: avoid; page-break-inside: avoid; display: flex; align-items: center; gap: 8px; padding: 3px 0; border-bottom: 1px solid #e5e7eb; }
    .cb { width: 16px; height: 16px; border: 2px solid #000; border-radius: 3px; display: inline-flex; align-items: center; justify-content: center; font-weight: 900; font-size: 12px; line-height: 1; }
    .name { font-weight: 800; font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  `;

  const buildSundayListPrintHtml = () => {
    const sorted = [...students].sort((a:any,b:any) => (a.firstName || '').localeCompare(b.firstName || '', 'da'));
    const rows = sorted.map((s:any) => {
      const mark = (sundayShowCrosses && s.isPresent) ? 'X' : '';
      const full = `${s.firstName || ''} ${s.lastName || ''}`.trim();
      return `<div class="item"><span class="cb">${mark}</span><span class="name">${escapeHtml(full)}</span></div>`;
    }).join('');
    const colCount = sorted.length <= 85 ? 3 : 4;
    return {
      html: `<h1>${escapeHtml(`${weekendLabel} • Søndagsliste`)}</h1><div class="rule"></div><div class="list">${rows}</div>`,
      css: sundayListPrintCss(colCount),
    };
  };


  const escapeHtml = (s: any) => String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');

  const wpRow = (time: string, main: string, sub?: string) => `
    <div class="wp-row">
      <div class="wp-time">${escapeHtml(time)}</div>
      <div>
        <div class="wp-main">${escapeHtml(main)}</div>
        ${sub ? `<div class="wp-sub">${escapeHtml(sub)}</div>` : ``}
      </div>
    </div>
  `;

  
  const wpMiniRow = (time: string, text: string) => {
    if (!text) return '';
    return `<div class="wp-row wp-row-mini">
      <div class="wp-time">${escapeHtml(time)}</div>
      <div class="wp-title">${escapeHtml(text)}</div>
    </div>`;
  };

const wpDayHtml = (title: string, rowsHtml: string) => `
    <section class="wp-day">
      <h2>${escapeHtml(title)}</h2>
      <div class="wp-list">${rowsHtml}</div>
    </section>
  `;

  const buildWeekendplanPrintHtml = () => {
    const friday = wpDayHtml('Fredag', [
      wpRow('14.40', 'Weekendstart efter sang', 'Beskeder om weekenden • Meld hvis du sover et andet sted'),
      wpMiniRow('17.00', `Før aftensmad (${getNamesFormatted(taskAssignments['f1'] || [])})`),
      wpRow('18.00', 'Aftensmad (obligatorisk)', 'Alle skal være der • Program, servering og sovetider gennemgås'),
      wpMiniRow('19.00', `Efter aftensmad (${getNamesFormatted(taskAssignments['f2'] || [])})`),
      wpRow('19.00', 'Program gennemgås', ''),
      wpRow('21.00', 'Aftenservering (Køkkenelever stiller frem)', ''),
      wpMiniRow('21.15', `Aftenservering (${getNamesFormatted(taskAssignments['f3'] || [])})`),
      wpRow('23.15', 'På sovestedet', 'Lavt støjniveau – vis hensyn'),
      wpRow('00.00', 'GODNAT'),
    ].join(''));

    const saturday = wpDayHtml('Lørdag', [
      wpRow('09.30', 'Skolen åbnes – køkkenelever møder', 'Køkkenelever møder'),
      wpMiniRow('09.30', `Før mokost (${getNamesFormatted(taskAssignments['l1'] || [])})`),
      wpRow('10.30', 'MOKOST', 'Dagens program gennemgås'),
      wpMiniRow('11.00', `Efter mokost (${getNamesFormatted(taskAssignments['l2'] || [])})`),
      wpRow('11.00', 'Fælles rengøring', 'Gange, fællesrum, hal m.m. (11.00–11.30)'),
      wpRow('14.00', 'Eftermiddagsservering (Køkkenelever stiller frem)', ''),
      wpMiniRow('14.15', `Eftermiddagsservering (${getNamesFormatted(taskAssignments['l5'] || [])})`),
      wpMiniRow('17.00', `Før aftensmad (${getNamesFormatted(taskAssignments['l3'] || [])})`),
      wpRow('18.00', 'AFTENSMAD', ''),
      wpMiniRow('19.00', `Efter aftensmad (${getNamesFormatted(taskAssignments['l4'] || [])})`),
      wpRow('21.00', 'Aftenservering', ''),
      wpMiniRow('21.15', `Aftenservering (${getNamesFormatted(taskAssignments['l6'] || [])})`),
      wpRow('23.00', 'På sovestedet', ''),
      wpRow('00.00', 'GODNAT', ''),
    ].join(''));

    const sunday = wpDayHtml('Søndag', [
      wpRow('09.30', 'Morgen – som lørdag', ''),
      wpMiniRow('09.30', `Før mokost (${getNamesFormatted(taskAssignments['s1'] || [])})`),
      wpRow('10.30', 'MOKOST + RENGØRING', ''),
      wpMiniRow('11.00', `Efter mokost (${getNamesFormatted(taskAssignments['s2'] || [])})`),
      wpRow('14.00', 'Eftermiddagsservering', ''),
      wpMiniRow('14.15', `Eftermiddagsservering (${getNamesFormatted(taskAssignments['s5'] || [])})`),
      wpRow('17.00', 'VAGTSKIFTE', 'Weekendlærere går – søndagslærere overtager'),
      wpMiniRow('16.30', `Før aftensmad (${getNamesFormatted(taskAssignments['s3'] || [])})`),
      wpRow('18.00', 'Elever kommer tilbage', 'Kryds af på søndagslisten • Spis hjemme'),
      wpMiniRow('19.00', `Efter aftensmad (${getNamesFormatted(taskAssignments['s4'] || [])})`),
      wpRow('21.15', 'AFTENSAMLING (OBLIGATORISK)', 'Tjek af alle er tilbage • Info om uge + sang'),
      wpMiniRow('21.15', `Aftenservering (${getNamesFormatted(taskAssignments['s6'] || [])})`),
      wpRow('21.30', 'På egen gang', ''),
      wpRow('23.00', 'GODNAT', ''),
    ].join(''));

    
    const photoHtml = weekendplanPhoto
      ? `<div class="wp-photo-wrap"><img class="wp-photo" src="${String(weekendplanPhoto).replace(/\"/g, '&quot;')}" alt="Weekend-selfie"/></div>`
      : '';

    return `
      <div class="print-weekendplan">
        <h1>WEEKENDPLAN FOR ${escapeHtml(weekendLabel)}</h1>
        <div class="wp-grid">
          <div class="wp-col wp-col-left">${friday}${saturday}</div>
          <div class="wp-col wp-col-right">${sunday}${photoHtml}</div>
        </div>
      </div>
    `;

  };

  const printHtmlInIframe = (html: string, css: string) => {
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentDocument!;
    doc.open();
    doc.write(`<!doctype html><html><head><meta charset="utf-8" />
      <title>Print</title>
      <style>${css}</style>
    </head><body>${html}</body></html>`);
    doc.close();

    const w = iframe.contentWindow!;
    w.focus();
    // Give the browser a tick to layout before printing (helps in Chrome)
    setTimeout(() => {
      w.print();
      setTimeout(() => document.body.removeChild(iframe), 800);
    }, 50);
  };

  const handlePrintNow = () => {
    const isMainPreview = previewType === 'main';
    const onlyWeekendplan = isMainPreview && !!printWeekendPlan && !printTasks && !printCleaning;

    if (onlyWeekendplan) {
      printHtmlInIframe(buildWeekendplanPrintHtml(), weekendplanPrintCss);
      return;
    }

    window.print();
  };
  // Print-knapper (2-trins): Weekendplan (landscape via iframe) og lister (portrait via window.print)
  const handlePrintWeekendplanOnly = () => {
    // Tving stabil landscape-print i Chrome via iframe + separat @page
    const html = buildWeekendplanPrintHtml();
    printHtmlInIframe(html, weekendplanPrintCss);
  };

  const handlePrintListsOnly = () => {
    // Print kun tjanselister + rengøring i portrait via app'ens normale print-CSS
    const prev = { wp: printWeekendPlan, tasks: printTasks, cleaning: printCleaning };

    // Sørg for at weekendplan ikke er med i dette print-job
    if (prev.wp) setPrintWeekendPlan(false);

    // Hvis brugeren har slået begge lister fra, så giver vi dem mindst én (tjanselister)
    if (!prev.tasks && !prev.cleaning) setPrintTasks(true);

    const restore = () => {
      // Gendan brugerens valg efter print
      setPrintWeekendPlan(prev.wp);
      setPrintTasks(prev.tasks);
      setPrintCleaning(prev.cleaning);
    };

    let fallbackTimer: number | null = null;

    // afterprint er ikke 100% på tværs af alle browsere, men i Chrome/Edge er den stabil nok til dette brug
    const onAfterPrint = () => {
      window.removeEventListener('afterprint', onAfterPrint);
      if (fallbackTimer !== null) window.clearTimeout(fallbackTimer);
      restore();
    };
    window.addEventListener('afterprint', onAfterPrint);

    // Fallback hvis afterprint ikke fyrer (fx hvis printdialogen lukkes på anden måde)
    fallbackTimer = window.setTimeout(() => {
      window.removeEventListener('afterprint', onAfterPrint);
      restore();
    }, 4000);

    // Vent en tick så React når at re-render før printdialogen åbnes
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        window.print();
      });
    });
  };


  const handlePrintSundayListOnly = () => {
    const { html, css } = buildSundayListPrintHtml();
    printHtmlInIframe(html, css);
  };

  const handlePrintBrandOnly = () => {
    // Brandlisten printes via app'ens normale brand-udskrift (portrait) – stabil pagination og alfabetisk DOM
    window.print();
  };




  return (
    <div 
      onMouseDown={(e:any) => { if(e.target.tagName !== 'INPUT' && e.target.tagName !== 'BUTTON') { touchStart.current = e.clientX; touchStartY.current = e.clientY; } }}
      onMouseUp={(e:any) => { if(touchStart.current !== null) { 
        const diff = touchStart.current - e.clientX; 
        const diffY = (touchStartY.current || 0) - e.clientY;
        const currentIdx = TABS.indexOf(activeTab);
        if (diffY < -150 && Math.abs(diff) < 50) setActiveTab('import');
        else if (Math.abs(diff) > 100 && Math.abs(diffY) < 100) {
          if (diff > 0 && currentIdx < TABS.length - 1) setActiveTab(TABS[currentIdx + 1]);
          if (diff < 0 && currentIdx > 0) setActiveTab(TABS[currentIdx - 1]);
        }
        touchStart.current = null;
      } }}
      onTouchStart={handleTouchStart} 
      onTouchEnd={handleTouchEnd} 
      className={`min-h-screen font-sans select-none ${previewType ? 'bg-white text-black' : 'bg-[#0A0E1A] flex justify-center'}`}
    >
      <div className={previewType ? 'w-full' : 'w-full max-w-[480px] bg-[#0A0E1A] min-h-screen relative pb-32'}>
        {!previewType && (
          <>
            <header className="p-6 border-b border-white/10 flex justify-between items-center sticky top-0 bg-[#0A0E1A]/90 backdrop-blur-xl z-50">
              <div className="flex items-center gap-3 shrink-0"><Compass className="w-8 h-8 text-[#FFB300]"/><h1 className="text-xl font-black uppercase italic tracking-tighter hidden sm:block">Weekend HU</h1></div>
              {(activeTab === 'tasks' || activeTab === 'cleaning') && !isGlobalLocked && (
                <div className="flex-1 flex justify-center px-4 animate-in slide-in-from-top-4 duration-300">
                  <button onClick={requestMotionPermission} className="bg-[#FFB300] text-black p-4 rounded-2xl font-black uppercase shadow-lg shadow-[#FFB300]/20 active:scale-90 transition-all flex items-center justify-center">
                    <Dices className="w-7 h-7"/>
                  </button>
                </div>
              )}
              <div className="flex gap-2 shrink-0 ml-auto">
                <button onClick={() => setIsGlobalLocked(!isGlobalLocked)} className={`p-2 transition-all ${isGlobalLocked ? 'text-red-500' : 'text-[#00BFA5] opacity-30'}`}>{isGlobalLocked ? <ShieldAlert/> : <ShieldCheck/>}</button>
                <button onClick={() => setShowInfo(true)} className="p-2 opacity-30"><Info/></button>
              </div>
            </header>

            <main className="p-4 space-y-6">
              {activeTab === 'import' && (
                <div className="space-y-6 animate-in fade-in">
                  <div className="grid grid-cols-2 gap-4 pt-4">
                     <div className="bg-white/5 border border-white/10 p-5 rounded-3xl"><Users className="w-5 h-5 text-[#FFB300] mb-2"/><p className="text-2xl font-black">{stats.present}</p><p className="text-[10px] font-black uppercase opacity-40">Tilstede</p></div>
                     <div className="bg-white/5 border border-white/10 p-5 rounded-3xl"><Utensils className="w-5 h-5 text-[#00BFA5] mb-2"/><p className="text-2xl font-black">{stats.kitchen}</p><p className="text-[10px] font-black uppercase opacity-40">Køkkenhold</p></div>
                  </div>
                  {stats.total > 0 && (
                    <button onClick={() => setActiveTab('rounds')} className="w-full p-8 bg-[#FFB300] text-black rounded-[2.5rem] font-black uppercase italic flex justify-between items-center shadow-xl active:scale-95 transition-all">Start Gangrunden <ChevronRight/></button>
                  )}
                  <div className="bg-white/5 p-12 rounded-[3.5rem] border-2 border-dashed border-white/10 text-center">
                    <Database className="mx-auto w-12 h-12 text-[#FFB300] mb-4"/><input type="file" id="up" className="hidden" onChange={handleFileUpload} accept=".xlsx,.xls,.csv"/><label htmlFor="up" className="block w-full py-5 bg-[#00BFA5] text-black rounded-2xl font-black uppercase cursor-pointer shadow-lg mb-4">Hent Elevliste</label>
                    
                    <button onClick={loadDemoData} className="w-full py-5 mb-4 bg-white/5 border border-white/20 text-white rounded-2xl font-black uppercase text-[10px] flex items-center justify-center gap-2 active:scale-95 transition-all"><Zap className="w-4 h-4 text-[#FFB300]"/> Demo Data (150 elever)</button>

                    <div className="flex gap-2">
                       <button onClick={() => { const data = localStorage.getItem(STORAGE_KEY); if(data){ const b = new Blob([data],{type:'application/json'}); const u=URL.createObjectURL(b); const a=document.createElement('a'); a.href=u; a.download = buildBackupFilename(); a.click(); } }} className="flex-1 py-4 bg-white/5 border border-white/10 rounded-2xl font-black uppercase text-[10px] flex items-center justify-center gap-2"><Download className="w-4 h-4"/> Backup</button>
                       <input type="file" id="restore" className="hidden" onChange={(e) => { 
                         const f=e.target.files?.[0]; 
                         if(f){ 
                           const r=new FileReader(); 
                           r.onload=(ev)=>{ 
                             try{ 
                               const target = ev.target as FileReader;
                               const res = target?.result;
                               if (typeof res === 'string') {
                                 const p=JSON.parse(res) as any; 
                                 if(p.students) setStudents(p.students);
                                 if(p.weekendNum) setWeekendNum(p.weekendNum);
                                 if(p.weekendName) setWeekendName(p.weekendName);
                                 if(p.isGlobalLocked !== undefined) setIsGlobalLocked(p.isGlobalLocked);
                                 if(p.taskAssignments) setTaskAssignments(p.taskAssignments);
                                 if(p.cleaningAssignments) setCleaningAssignments(p.cleaningAssignments);
                                 if(p.lockedAreas) setLockedAreas(p.lockedAreas);
                                 if(p.checkedRounds) setCheckedRounds(p.checkedRounds);
                                 if(p.checkedTasks) setCheckedTasks(p.checkedTasks);
                                 if(p.checkedCleaning) setCheckedCleaning(p.checkedCleaning);
                                 setActiveTab('import'); alert("Alt data gendannet!"); 
                               }
                             }catch(e){alert("Fejl i fil: " + (e instanceof Error ? e.message : String(e)));} 
                           }; 
                           r.readAsText(f); 
                         } 
                       }} accept=".json"/><label htmlFor="restore" className="flex-1 py-4 bg-white/5 border border-white/10 rounded-2xl font-black uppercase text-[10px] flex items-center justify-center gap-2 cursor-pointer"><RotateCcw className="w-4 h-4"/> Restore</label>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'students' && (
                stats.total === 0 ? <EmptyState tab="Elevlisten"/> : (
                <div className="space-y-4 animate-in fade-in">
                  <div className="flex gap-2 sticky top-24 z-40 bg-[#0A0E1A] py-2">
                    <div className="flex-1 relative"><Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 opacity-20"/><input type="text" placeholder="Søg..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full bg-white/5 border border-white/10 p-5 rounded-2xl outline-none focus:border-[#00BFA5]"/></div>
                    <button onClick={() => setShowAllStudents(!showAllStudents)} className={`px-6 rounded-2xl font-black uppercase text-[10px] border ${showAllStudents ? 'bg-[#00BFA5] text-black' : 'bg-white/5 border-white/10 opacity-40'}`}>Alle</button>
                  </div>
                  {students
                    .filter(s => (showAllStudents || s.isPresent) && `${s.firstName} ${s.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()))
                    .sort((a, b) => a.firstName.localeCompare(b.firstName))
                    .map((s, i) => (
                    <div key={s.id} className={`flex items-stretch rounded-[2.2rem] overflow-hidden ${WISE_COLORS[i % 5]} text-black ${!s.isPresent ? 'opacity-20 grayscale' : ''} shadow-lg`}>
                      <div className="flex-1 p-6" onClick={() => {
                          if (isGlobalLocked) return;
                          if (s.isPresent) {
                            const ok = window.confirm(`Frameld ${s.firstName} ${s.lastName} fra weekenden?`);
                            if (!ok) return;
                          }
                          setStudents(p => p.map(x => x.id === s.id ? { ...x, isPresent: !x.isPresent } : x));
                        }}><p className="text-xl font-black leading-tight flex items-center gap-2 flex-wrap"><span>{s.firstName} {s.lastName}</span>{(taskCountByStudent[s.id] || 0) > 1 && (<span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-[#00BFA5]/15 border border-[#00BFA5]/35 text-[10px] font-black tabular-nums"><Utensils size={12} className="opacity-80" />+{(taskCountByStudent[s.id] || 0) - 1}</span>)}{(cleaningCountByStudent[s.id] || 0) > 1 && (<span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-[#FFB300]/12 border border-[#FFB300]/35 text-[10px] font-black tabular-nums"><Trash2 size={12} className="opacity-80" />+{(cleaningCountByStudent[s.id] || 0) - 1}</span>)}</p><p className="text-[10px] font-bold uppercase opacity-50 mt-1">{s.house} • {s.room}</p></div>
                      <button disabled={isGlobalLocked} onClick={() => setStudents(p => p.map(x => x.id === s.id ? {...x, isKitchenDuty: !x.isKitchenDuty} : x))} className={`px-8 text-[10px] font-black uppercase ${s.isKitchenDuty ? 'bg-black text-white' : 'bg-black/10'}`}>Køkken</button>
                    </div>
                  ))}
                </div>)
              )}

              {activeTab === 'rounds' && (
                stats.total === 0 ? <EmptyState tab="Gangrunder"/> : (
                <div className="space-y-6 animate-in fade-in">
                   <div className="sticky top-0 z-30 px-4 pt-2 pb-4 -mx-4 bg-[#0B1020]/80 backdrop-blur-xl border-b border-white/5">
  <div className="flex justify-between items-center px-4">
    <h2 className="text-2xl font-black uppercase italic">Gangrunder</h2>
    <div className="flex bg-white/5 p-1 rounded-xl">
      {['Fredag', 'Lørdag', 'Søndag'].map(d => (
        <button
          key={d}
          onClick={() => setBrandListDay(d as any)}
          className={`px-4 py-2 text-[9px] font-black uppercase rounded-lg ${brandListDay === d ? 'bg-[#FFB300] text-black' : 'opacity-40'}`}
        >
          {d}
        </button>
      ))}
    </div>
  </div>
</div>
                   {groupedRounds.map(([area, sids], idx) => (
                     <AreaCard 
                       key={area} id={area} label={area} studentsInArea={sids} type="rounds" idx={idx}
                       {...commonProps}
                       checkedMap={checkedRounds} setCheckedMap={setCheckedRounds}
                       lockedAreas={lockedAreas} setLockedAreas={setLockedAreas}
                     />
                   ))}
                </div>)
              )}

              {activeTab === 'tasks' && (
                stats.total === 0 ? <EmptyState tab="Madtjanser"/> : (
                <div className="space-y-6 animate-in fade-in">
                  <div className="flex justify-between items-center px-4"><h2 className="text-2xl font-black uppercase italic">Madtjanser</h2></div>
                  <AreaCard 
                    id="pool" label="Ikke tildelt (Puljen)" studentsInArea={students.filter(s => s.isPresent && !s.isKitchenDuty && !Object.values(taskAssignments).flat().includes(s.id)).map(s => s.id)} type="tasks" idx={99}
                    {...commonProps}
                    checkedMap={checkedTasks} setCheckedMap={setCheckedTasks}
                    lockedAreas={lockedAreas} setLockedAreas={setLockedAreas}
                  />
                  {FIXED_TASKS.map((task, idx) => (
                    <AreaCard 
                      key={task.id} id={task.id} label={task.label} studentsInArea={taskAssignments[task.id] || []} type="tasks" idx={idx}
                      {...commonProps}
                      checkedMap={checkedTasks} setCheckedMap={setCheckedTasks}
                      lockedAreas={lockedAreas} setLockedAreas={setLockedAreas}
                    />
                  ))}
                </div>)
              )}

              {activeTab === 'cleaning' && (
                stats.total === 0 ? <EmptyState tab="Rengøring"/> : (
                <div className="space-y-6 animate-in fade-in">
                  <div className="flex justify-between items-center px-4"><h2 className="text-2xl font-black uppercase italic">Rengøringstjek</h2></div>
                  <AreaCard 
                    id="pool" label="På egen gang (Puljen)" studentsInArea={students.filter(s => s.isPresent && !s.isKitchenDuty && !mokostExcludedIds.has(s.id) && !FIXED_CLEANING.some(fc => cleaningAssignments[fc.name]?.includes(s.id))).map(s => s.id)} type="cleaning" idx={99} 
                    {...commonProps}
                    checkedMap={checkedCleaning} setCheckedMap={setCheckedCleaning}
                    lockedAreas={lockedAreas} setLockedAreas={setLockedAreas}
                  />
                  <h3 className="text-[10px] font-black uppercase opacity-40 px-4 pt-6 italic">Fællesområder</h3>
                  {cleaningAreasForOverview.map((area, idx) => (
                    <AreaCard 
                      key={area.name} id={area.name} label={area.name} studentsInArea={cleaningAssignments[area.name] || []} type="cleaning" idx={idx}
                      {...commonProps}
                      checkedMap={checkedCleaning} setCheckedMap={setCheckedCleaning}
                      lockedAreas={lockedAreas} setLockedAreas={setLockedAreas}
                    />
                  ))}
                  <h3 className="text-[10px] font-black uppercase opacity-40 px-4 pt-6 italic">Gange</h3>
                  {Array.from(new Set(students.map(s => s.house as string))).sort().map((house, idx) => (
                    <AreaCard 
                      key={house} id={house} label={house} studentsInArea={cleaningAssignments[house] || []} type="cleaning" idx={idx + 20}
                      {...commonProps}
                      checkedMap={checkedCleaning} setCheckedMap={setCheckedCleaning}
                      lockedAreas={lockedAreas} setLockedAreas={setLockedAreas}
                    />
                  ))}
                </div>)
              )}

              {activeTab === 'print' && (
                <div className="py-10 space-y-6 animate-in fade-in pb-12">
                  <div className="bg-white/5 p-8 rounded-[3rem] border border-white/10 space-y-6">
                       <span className="text-[10px] font-black uppercase opacity-40 tracking-widest italic">Uge & Navn</span>
                       <div className="flex gap-4">
                         <div className="flex-1">
                           <p className="text-[9px] uppercase font-black opacity-30 mb-1 italic">Uge nr.</p>
                           <input type="number" value={weekendNum} onChange={e => setWeekendNum(e.target.value)} className="bg-transparent border-b-2 border-white/20 w-full text-2xl font-black outline-none text-[#FFB300]"/>
                         </div>
                         <div className="flex-[3]">
                           <p className="text-[9px] uppercase font-black opacity-30 mb-1 italic">Weekend Navn</p>
                           <input type="text" placeholder="Navn på weekend..." value={weekendName} onChange={e => setWeekendName(e.target.value)} className="bg-transparent border-b-2 border-white/20 w-full text-lg font-black outline-none text-white"/>
                         </div>
                       </div>
                       <div className="flex bg-white/5 p-1 rounded-2xl mt-4">{['Fredag', 'Lørdag', 'Søndag'].map(d => <button key={d} onClick={() => setBrandListDay(d as any)} className={`flex-1 py-3 text-[10px] font-black uppercase rounded-xl ${brandListDay === d ? 'bg-[#FFB300] text-black' : 'opacity-40'}`}>{d}</button>)}</div>
                  </div>
                  <div className="grid gap-4">
                    <button onClick={() => setPreviewType('main')} className="w-full p-8 bg-[#FFB300] text-black rounded-[2.5rem] font-black uppercase flex justify-between items-center italic shadow-lg shadow-[#FFB300]/10">Program & Reng. <LayoutDashboard/></button>
                    <button onClick={() => setPreviewType('brand')} className="w-full p-8 bg-[#D81B60] text-white rounded-[2.5rem] font-black uppercase flex justify-between items-center italic shadow-lg shadow-[#D81B60]/10">Brandlister ({brandListDay}) <Flame/></button>
                    <button onClick={() => setPreviewType('sunday')} className="w-full p-8 bg-[#1E88E5] text-white rounded-[2.5rem] font-black uppercase flex justify-between items-center italic shadow-lg shadow-[#1E88E5]/10">Søndagsliste <Users/></button>
                  </div>
                </div>
              )}
            </main>

            <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-[#0A0E1A]/95 backdrop-blur-3xl border-t border-white/10 p-6 flex justify-around items-center z-50 shadow-2xl">
              {[{ id: 'import', icon: LayoutDashboard }, { id: 'students', icon: Users }, { id: 'rounds', icon: Compass }, { id: 'tasks', icon: Utensils }, { id: 'cleaning', icon: Trash2 }, { id: 'print', icon: FileText }].map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`p-3 rounded-2xl transition-all ${activeTab === tab.id ? 'bg-[#FFB300] text-black scale-110 shadow-xl' : 'opacity-20'}`}><tab.icon className="w-6 h-6"/></button>
              ))}
            </nav>
          </>
        )}

        {/* --- PREVIEWS --- */}
        {previewType && (
          <div className="bg-white text-black min-h-screen">
             <div className="no-print fixed top-0 left-0 right-0 bg-black text-white z-[1000] flex flex-col border-b border-white/10 shadow-2xl">
                <div className="p-6 flex justify-between items-center gap-4">
                  <button onClick={() => setPreviewType(null)} className="p-3 bg-white/10 rounded-full active:scale-90 transition-transform"><X/></button>
                  <div className="ml-auto flex items-center gap-2">
                    {previewType === 'main' && (
                      <>
                        <button onClick={handlePrintWeekendplanOnly} className="px-8 py-3 bg-[#00BFA5] text-black rounded-2xl font-black uppercase text-[11px] shadow-xl">Print weekendplan</button>

                        {/* Weekend-selfie (valgfrit) – bruges kun i Weekendplan-print */}
                        <input
                          ref={photoInputRef}
                          type="file"
                          accept="image/*"
                          capture="user"
                          onChange={handleWeekendplanPhotoFile}
                          className="hidden"
                        />
                        <button
                          onClick={handlePickWeekendplanPhoto}
                          className="px-4 py-3 bg-white/10 text-white rounded-2xl font-black uppercase text-[11px] border border-white/15 hover:bg-white/15"
                          title="Upload foto til Weekendplan-print"
                        >
                          Upload foto
                        </button>
                        {weekendplanPhoto && (
                          <>
                            <span className="text-[11px] font-semibold opacity-80 ml-2">klar til print</span>
                            <button
                              onClick={handleDeleteWeekendplanPhoto}
                              className="px-4 py-3 bg-white/5 text-white rounded-2xl font-black uppercase text-[11px] border border-white/15 hover:bg-white/10"
                              title="Slet foto"
                            >
                              Slet
                            </button>
                          </>
                        )}
                        <button onClick={handlePrintListsOnly} className="px-8 py-3 bg-[#FFB300] text-black rounded-2xl font-black uppercase text-[11px] shadow-xl">Print tjanser</button>
                      </>
                    )}
                    {previewType === 'brand' && (
                      <button onClick={handlePrintBrandOnly} className="px-8 py-3 bg-[#D81B60] text-white rounded-2xl font-black uppercase text-[11px] shadow-xl">Print brandlister</button>
                    )}
                    {previewType === 'sunday' && (
                      <button onClick={handlePrintSundayListOnly} className="px-8 py-3 bg-[#1E88E5] text-white rounded-2xl font-black uppercase text-[11px] shadow-xl">Print søndagsliste</button>
                    )}
                  </div>
                </div>
                <div className="px-6 pb-6 flex gap-3 overflow-x-auto custom-scroll pb-2">
                  {previewType === 'main' && (
                    <>
                      <button onClick={() => setPrintWeekendPlan(!printWeekendPlan)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase border transition-all shrink-0 ${printWeekendPlan ? 'bg-[#00BFA5] text-black border-[#00BFA5]' : 'bg-white/5 border-white/20 opacity-40'}`}>Weekendplan</button>
                      <button onClick={() => setPrintTasks(!printTasks)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase border transition-all shrink-0 ${printTasks ? 'bg-[#FFB300] text-black border-[#FFB300]' : 'bg-white/5 border-white/20 opacity-40'}`}>Tjanselister</button>
                      <button onClick={() => setPrintCleaning(!printCleaning)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase border transition-all shrink-0 ${printCleaning ? 'bg-[#D81B60] text-white border-[#D81B60]' : 'bg-white/5 border-white/20 opacity-40'}`}>Rengøring</button>
                    </>
                  )}
                  {previewType === 'brand' && (
                    <>
                      {['Fredag', 'Lørdag', 'Søndag'].map(d => (
                        <button key={d} onClick={() => setBrandListDay(d as any)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase border transition-all shrink-0 ${brandListDay === d ? 'bg-[#D81B60] text-white border-[#D81B60]' : 'bg-white/5 border-white/20 opacity-40'}`}>{d}</button>
                      ))}
                    </>
                  )}
                  {previewType === 'sunday' && (
                    <button onClick={() => setSundayShowCrosses(!sundayShowCrosses)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase border transition-all shrink-0 ${sundayShowCrosses ? 'bg-[#1E88E5] text-white border-[#1E88E5]' : 'bg-white/5 border-white/20 opacity-40'}`}>Vis X ved tilstede</button>
                  )}
                </div>
             </div>

             <div className="max-w-4xl mx-auto pt-44 print:pt-0">
                {previewType === 'main' && (
                  <>
                    {printWeekendPlan && (
                      <div className="a4-page p-12 text-black">
                        <h1 className="text-3xl font-black italic uppercase border-b-4 border-black pb-4 mb-8 text-center tracking-tighter">Weekendplan for {weekendLabel}</h1>

                        <div className="space-y-8">
                          {/* FREDAG */}
                          <section>
                            <div className="flex items-center gap-3 mb-4 bg-slate-50 p-2 rounded-lg border-l-4 border-[#FFB300]"><Sunrise className="w-5 h-5"/><h2 className="text-lg font-black uppercase italic">Fredag</h2></div>
                            <div className="ml-2 space-y-3 border-l-2 border-slate-100 pl-4 py-1">
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">14.40</span><div><p className="font-bold text-sm">Weekendstart efter sang</p><p className="text-[10px] opacity-60">Beskeder om weekenden • Meld hvis du sover et andet sted</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">17.00</span><p className="text-[11px] font-normal italic">Før aftensmad <span className="font-bold italic">({getNamesFormatted(taskAssignments['f1'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">18.00</span><div><p className="font-bold text-sm">Aftensmad (obligatorisk)</p><p className="text-[10px] opacity-60">Alle skal være der • Program, servering og sovetider gennemgås</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">19.00</span><p className="text-[11px] font-normal italic">Efter aftensmad <span className="font-bold italic">({getNamesFormatted(taskAssignments['f2'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">21.00</span><div><p className="font-bold text-sm">Aftenservering (Køkkenelever stiller frem)</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">21.15</span><p className="text-[11px] font-normal italic">Aftenservering <span className="font-bold italic">({getNamesFormatted(taskAssignments['f3'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">23.15</span><div><p className="font-bold text-sm">På sovestedet</p><p className="text-[10px] opacity-60">Lavt støjniveau – vis hensyn</p></div></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">00.00</span><div><p className="font-bold uppercase italic tracking-tighter text-sm">GODNAT</p></div></div>
                            </div>
                          </section>

                          {/* LØRDAG */}
                          <section>
                            <div className="flex items-center gap-3 mb-4 bg-slate-50 p-2 rounded-lg border-l-4 border-[#00BFA5]"><Sun className="w-5 h-5"/><h2 className="text-lg font-black uppercase italic">Lørdag</h2></div>
                            <div className="ml-2 space-y-3 border-l-2 border-slate-100 pl-4 py-1">
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">09.30</span><div><p className="font-bold text-sm">Skolen åbnes – køkkenelever møder</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">09.30</span><p className="text-[11px] font-normal italic">Før Mokost <span className="font-bold italic">({getNamesFormatted(taskAssignments['l1'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">10.30</span><div><p className="font-bold uppercase italic text-sm">MOKOST</p><p className="text-[10px] opacity-60">Dagens program gennemgås</p></div></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">11.00</span><div><p className="font-bold text-sm underline">Fælles rengøring</p><p className="text-[10px] opacity-60">Gange, fællesrum, hal m.m. (11.00–11.30)</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">11.00</span><p className="text-[11px] font-normal italic">Efter Mokost <span className="font-bold italic">({getNamesFormatted(taskAssignments['l2'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">14.00</span><div><p className="font-bold text-sm">Eftermiddagsservering (Køkkenelever stiller frem)</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">14.15</span><p className="text-[11px] font-normal italic">Eftermiddagsservering <span className="font-bold italic">({getNamesFormatted(taskAssignments['l5'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">17.00</span><p className="text-[11px] font-normal italic">Før aftensmad <span className="font-bold italic">({getNamesFormatted(taskAssignments['l3'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">18.00</span><div><p className="font-bold italic uppercase text-sm">AFTENSMAD</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">18.45</span><p className="text-[11px] font-normal italic">Efter aftensmad <span className="font-bold italic">({getNamesFormatted(taskAssignments['l4'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">21.00</span><div><p className="font-bold text-sm">Aftenservering</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">21.15</span><p className="text-[11px] font-normal italic">Aftenservering <span className="font-bold italic">({getNamesFormatted(taskAssignments['l6'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">23.00</span><div><p className="font-bold text-sm">På sovestedet</p></div></div>
                            </div>
                          </section>

                          {/* SØNDAG */}
                          <section>
                            <div className="flex items-center gap-3 mb-4 bg-slate-50 p-2 rounded-lg border-l-4 border-[#1E88E5]"><Moon className="w-5 h-5"/><h2 className="text-lg font-black uppercase italic">Søndag</h2></div>
                            <div className="ml-2 space-y-3 border-l-2 border-slate-100 pl-4 py-1">
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">09.30</span><div><p className="font-bold text-sm">Morgen – som lørdag</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">09.30</span><p className="text-[11px] font-normal italic">Før Mokost <span className="font-bold italic">({getNamesFormatted(taskAssignments['s1'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">10.30</span><div><p className="font-bold uppercase italic text-sm">MOKOST + RENGØRING</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">10.30</span><p className="text-[11px] font-normal italic">Efter mokost <span className="font-bold italic">({getNamesFormatted(taskAssignments['s2'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">14.00</span><div><p className="font-bold text-sm">Eftermiddagsservering</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">14.15</span><p className="text-[11px] font-normal italic">Eftermiddagsservering <span className="font-bold italic">({getNamesFormatted(taskAssignments['s5'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">17.00</span><div><p className="font-bold text-[#D81B60] uppercase text-sm">VAGTSKIFTE</p><p className="text-[10px] opacity-60 italic">Weekendlærere går – søndagslærere overtager</p></div></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">18.00</span><div><p className="font-bold text-sm">Elever kommer tilbage</p><p className="text-[10px] opacity-60">Kryds af på søndagslisten • Spis hjemme</p></div></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">21.15</span><div><p className="font-bold uppercase italic text-sm">AFTENSAMLING (OBLIGATORISK)</p><p className="text-[10px] opacity-60 italic">Tjek at alle er tilbage • Info om ugen + sang</p></div></div>
                               <div className="flex items-baseline gap-4 ml-16 opacity-70"><span className="w-12 shrink-0 text-[11px] font-normal italic">21.15</span><p className="text-[11px] font-normal italic">Aftenservering <span className="font-bold italic">({getNamesFormatted(taskAssignments['s6'] || [])})</span></p></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">21.30</span><div><p className="font-bold text-sm">På egen gang</p></div></div>
                               <div className="flex items-baseline gap-4"><span className="font-black w-12 shrink-0 text-sm">23.00</span><div><p className="font-bold uppercase italic text-sm">GODNAT</p></div></div>
                            </div>
                          </section>
                        </div>

                        <div className="mt-8 pt-6 border-t border-slate-100 flex justify-between items-center opacity-40 text-[9px] font-black uppercase">
                            <div className="flex items-center gap-2"><AlertCircle className="w-3 h-3"/> Meld hvis du sover et andet sted</div>
                            <div className="flex items-center gap-2"><Clock className="w-3 h-3"/> Kom til måltider og samlinger</div>
                        </div>
                      </div>
                    )}

                    {printTasks && (
                      <div className="a4-page p-12">
                        <h1 className="text-3xl font-black italic uppercase border-b-4 border-black pb-4 mb-8 text-center">{weekendLabel} • Tjanseliste</h1>
                        <div className="grid grid-cols-2 gap-x-12">
{FIXED_TASKS.map(t => (
                            <div key={t.id} className="mb-6 border-b-2 border-slate-100 pb-3">
                              <p className="text-[10px] font-black uppercase opacity-40 mb-1">{t.label}</p>
                              <p className="font-bold text-lg">{getNamesFormatted(taskAssignments[t.id] || [])}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    {printCleaning && (
                      <div className="a4-page p-12">
                        <h1 className="text-3xl font-black italic uppercase border-b-4 border-black pb-4 mb-8 text-center">{weekendLabel} • Rengøring</h1>
                        <div className="grid grid-cols-2 gap-x-12">
                          {FIXED_CLEANING.map(c => (
                            <div key={c.name} className="mb-6 border-b-2 border-slate-100 pb-3">
                              <p className="text-[10px] font-black uppercase opacity-40 mb-1">{c.name}</p>
                              <p className="font-bold text-lg">{getNamesFormatted(cleaningAssignments[c.name] || [])}</p>
                            </div>
                          ))}
                          {Array.from(new Set(students.map(s => s.house as string))).sort().map(house => (
                            <div key={house} className="mb-6 border-b-2 border-slate-100 pb-3">
                               <p className="text-[10px] font-black uppercase opacity-40 mb-1">{house} (GANG)</p>
                               <p className="font-bold text-lg">{getNamesFormatted(cleaningAssignments[house] || [])}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                )}

                {previewType === 'brand' && (
                  groupedRounds.map(([area, sids]) => (
                    <div key={area} className={`a4-page border-[10px] border-red-600 ${sids.length > 18 ? 'p-8' : 'p-12'}`}>
                       <div className={`flex justify-between items-start ${sids.length > 16 ? 'mb-6' : 'mb-12'}`}>
                         <h1 className="text-6xl font-black text-red-600 italic uppercase leading-none truncate max-w-[70%]">{area}</h1>
                         <div className="text-right">
                            <p className="text-xl font-black uppercase italic">Brandliste</p>
                            <p className="text-2xl font-black text-red-600 italic leading-tight">{weekendLabel}</p>
                            <p className="text-3xl font-black italic uppercase">{brandListDay}</p>
                         </div>
                       </div>
                       <div className={`grid ${sids.length > 16 ? 'grid-cols-3' : 'grid-cols-2'} gap-x-6 gap-y-2`}>
                          {sids.map(sid => students.find(x => x.id === sid)).filter(Boolean).sort((a:any,b:any)=>a.firstName.localeCompare(b.firstName)).map((s:any, idx:number)=>(
                            <div key={idx} className="border-b-4 border-slate-200 py-4 text-3xl font-black uppercase italic flex justify-between items-baseline" style={{ fontSize: (sids.length > 18 ? 22 : sids.length > 14 ? 26 : 32), lineHeight: 1.0 }}>
                              <span>{s.firstName} {s.lastName}</span>
                              <span className="text-sm opacity-30 italic">{s.sleepingLocations?.[brandListDay]?.split(' - ')[1] || 'Gæst'}</span>
                            </div>
                          ))}
                       </div>
                    </div>
                  ))
                )}

                {previewType === 'sunday' && (
                  <div className="a4-page p-12">
                    <h1 className="text-4xl font-black italic uppercase border-b-4 border-black pb-4 mb-8">{weekendLabel} • Søndagsliste</h1>
                    <div className="sunday-columns">
                      {students.sort((a,b)=>a.firstName.localeCompare(b.firstName)).map((s, idx)=>(
                        <div key={idx} className="flex items-center gap-2 mb-2 border-b pb-1 text-[11px] font-bold">
                          <div className="w-5 h-5 border-2 border-black rounded flex items-center justify-center">
                            {(sundayShowCrosses && s.isPresent) ? 'X' : ''}
                          </div>
                          <span className="truncate">{s.firstName} {s.lastName}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
             </div>
          </div>
        )}

        {/* --- FLYT MODAL --- */}
        {editTarget && (
          <div className="fixed inset-0 bg-black/95 z-[5000] flex items-center justify-center p-4 backdrop-blur-xl">
            <div className="bg-[#151926] w-full max-w-[440px] rounded-[3rem] border border-white/10 flex flex-col max-h-[90vh] shadow-2xl overflow-hidden">
               <div className="p-8 border-b border-white/5 flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-black uppercase text-[#FFB300] italic">{getName(editTarget.sid)}</h3>
                    <p className="text-[10px] opacity-40 uppercase font-black italic">
                      {selectedMoveHouse ? `Vælg værelse på ${selectedMoveHouse}` : (targetStudent ? `${targetStudent.house} • ${targetStudent.room}` : '')}
                    </p>
                  </div>
                  <button onClick={() => setEditTarget(null)} className="p-3 bg-white/5 rounded-full"><X/></button>
               </div>
               <div className="flex-1 overflow-y-auto space-y-6 p-8 custom-scroll">
                  {editTarget.type === 'rounds' && (
                    <div className="space-y-8">
                       {!selectedMoveHouse ? (
                         <>
                           <div>
                             <button onClick={() => { if(targetStudent) handleMove(editTarget.sid, `${targetStudent.house} - ${targetStudent.room}`, 'rounds'); }} className="w-full p-6 bg-[#FFB300] text-black rounded-3xl font-black uppercase italic shadow-lg">Eget Værelse</button>
                           </div>
                           <section>
                             <h4 className="text-[10px] font-black uppercase opacity-40 italic mb-4">Fællesområder</h4>
                             <div className="grid grid-cols-2 gap-3">
                               {FIXED_SLEEP_AREAS.map(area => {
  const k = `rounds-${area}`;
  const locked = !!lockedAreas[k];
  return (
    <button
      key={area}
      disabled={locked}
      onClick={() => !locked && handleMove(editTarget.sid, area, 'rounds')}
      className={`p-5 rounded-2xl font-black uppercase text-[10px] italic border transition ${locked ? 'bg-[#D81B60]/20 border-[#D81B60]/50 text-white/90' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}
    >
      {area}
    </button>
  );
})}
                             </div>
                           </section>
                           <section>
                             <h4 className="text-[10px] font-black uppercase opacity-40 italic mb-4">Andre værelser på {targetStudent?.house}</h4>
                             <div className="grid grid-cols-4 gap-2">
                               {availableRoomsOnSameHouse.map(room => (
                                 // Fixed typo: editStudent.sid corrected to editTarget.sid
                                 <button key={room} onClick={() => { if(targetStudent) handleMove(editTarget.sid, `${targetStudent.house} - ${room}`, 'rounds'); }} className="p-3 bg-white/5 rounded-xl text-[10px] font-black hover:bg-white/10">{room}</button>
                               ))}
                             </div>
                           </section>
                           <section>
                             <h4 className="text-[10px] font-black uppercase opacity-40 italic mb-4">Flyt til anden gang</h4>
                             <div className="grid grid-cols-1 gap-2">
                               {otherHouses.map(house => {
  const k = `rounds-${house}`;
  const locked = !!lockedAreas[k];
  return (
    <button
      key={house}
      disabled={locked}
      onClick={() => !locked && setSelectedMoveHouse(house)}
      className={`p-5 rounded-2xl font-black uppercase text-[10px] italic flex justify-between items-center border transition ${locked ? 'bg-[#D81B60]/15 border-[#D81B60]/45 text-white/90' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}
    >
      <span>{house}</span>
      <ChevronRight className={`w-4 h-4 ${locked ? 'opacity-80' : 'opacity-30'}`} />
    </button>
  );
})}
                             </div>
                           </section>
                         </>
                       ) : (
                         <section className="animate-in slide-in-from-right duration-300">
                           <button onClick={() => setSelectedMoveHouse(null)} className="mb-6 flex items-center gap-2 text-[10px] font-black uppercase opacity-40 italic"><ChevronDown className="w-4 h-4 rotate-90"/> Tilbage til gange</button>
                           <h4 className="text-[10px] font-black uppercase opacity-40 italic mb-4">Vælg værelse på {selectedMoveHouse}</h4>
                           <div className="grid grid-cols-4 gap-2">
                             {roomsOnSelectedHouse.map(room => {
  const houseLocked = !!lockedAreas[`rounds-${selectedMoveHouse}`];
  const isOwnHouse = targetStudent && selectedMoveHouse === targetStudent.house;
  const disabled = houseLocked && !isOwnHouse;
  return (
    <button
      key={room}
      disabled={disabled}
      onClick={() => !disabled && handleMove(editTarget.sid, `${selectedMoveHouse} - ${room}`, 'rounds')}
      className={`p-3 rounded-xl text-[10px] font-black border transition ${disabled ? 'bg-[#D81B60]/15 border-[#D81B60]/45 text-white/90' : 'bg-[#00BFA5]/10 border-[#00BFA5]/20 hover:bg-[#00BFA5]/20'}`}
    >
      {room}
    </button>
  );
})}
                             <button disabled={!!lockedAreas[`rounds-${selectedMoveHouse}`] && !(targetStudent && selectedMoveHouse === targetStudent.house)} onClick={() => { const disabled = !!lockedAreas[`rounds-${selectedMoveHouse}`] && !(targetStudent && selectedMoveHouse === targetStudent.house); if(!disabled) handleMove(editTarget.sid, `${selectedMoveHouse} - Gæst`, 'rounds'); }} className={`p-3 rounded-xl text-[10px] font-black italic col-span-2 border ${!!lockedAreas[`rounds-${selectedMoveHouse}`] && !(targetStudent && selectedMoveHouse === targetStudent.house) ? 'bg-[#D81B60]/15 border-[#D81B60]/45 text-white/90' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}>Gæst</button>
                           </div>
                         </section>
                       )}
                    </div>
                  )}
                  {editTarget.type === 'tasks' && (
                    <><button onClick={() => handleMove(editTarget.sid, 'pool', 'tasks', 'move')} className="w-full p-6 bg-[#00BFA5] text-black rounded-3xl font-black uppercase italic mb-4 shadow-xl">Flyt til Puljen</button>

                      <div className="flex items-center gap-2 mb-4">
                        <button
                          onClick={() => setAssignMode('move')}
                          className={`flex-1 p-3 rounded-2xl text-[10px] font-black uppercase italic transition ${assignMode==='move' ? 'bg-white/10 border border-white/20' : 'bg-white/5 border border-white/10 hover:bg-white/10'}`}
                        >Flyt</button>
                        <button
                          onClick={() => setAssignMode('add')}
                          className={`flex-1 p-3 rounded-2xl text-[10px] font-black uppercase italic transition ${assignMode==='add' ? 'bg-[#00BFA5]/15 border border-[#00BFA5]/30' : 'bg-white/5 border border-white/10 hover:bg-white/10'}`}
                        >Tilføj ekstra</button>
                      </div>

                      {(() => {
                        const a = getStudentAssignments(editTarget.sid);
                        const hasExtra = a.extraTotal > 0;
                        const extraTasks = a.tasks.length > 1 ? a.tasks.slice(1) : [];
                        const extraCleaning = a.cleaning.length > 1 ? a.cleaning.slice(1) : [];
                        return (
                          <div className={`rounded-2xl border p-4 ${hasExtra ? 'bg-[#D81B60]/10 border-[#D81B60]/35' : 'bg-white/5 border-white/10'}`}>
                            {hasExtra ? (
                              <>
                                <div className="flex items-center justify-between gap-3">
                                  <div className="flex items-center gap-2">
                                    <AlertCircle size={16} className="text-[#D81B60]" />
                                    <div className="text-[12px] font-black uppercase italic tracking-wide">
                                      +{a.extraTotal} ekstra opgaver
                                    </div>
                                  </div>
                                  <div className="text-[11px] font-black tabular-nums opacity-80">
                                    {a.taskN}/{a.cleanN}
                                  </div>
                                </div>

                                <div className="mt-3 space-y-2">
                                  {extraTasks.map((t) => (
                                    <div key={'et-' + t} className="flex items-center gap-2">
                                      <Utensils size={14} className="opacity-80" />
                                      <span className="text-[11px] font-black italic">{t}</span>
                                    </div>
                                  ))}
                                  {extraCleaning.map((c) => (
                                    <div key={'ec-' + c} className="flex items-center gap-2">
                                      <Trash2 size={14} className="opacity-80" />
                                      <span className="text-[11px] font-black italic">{c}</span>
                                    </div>
                                  ))}
                                </div>
                              </>
                            ) : (
                              <div className="space-y-2 text-[11px] font-black italic">
                                <div className="flex items-center justify-between gap-3">
                                  <div className="flex items-center gap-2 opacity-80">
                                    <Utensils size={14} />
                                    <span className="truncate">{a.tasks[0] || '—'}</span>
                                  </div>
                                  <span className="tabular-nums opacity-70">{a.taskN}</span>
                                </div>
                                <div className="flex items-center justify-between gap-3">
                                  <div className="flex items-center gap-2 opacity-80">
                                    <Trash2 size={14} />
                                    <span className="truncate">{a.cleaning[0] || '—'}</span>
                                  </div>
                                  <span className="tabular-nums opacity-70">{a.cleanN}</span>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })()}

                      <div className="space-y-2">{tasksForPicker.map(task => {
                        const assigned = (taskAssignments[task.id] || []).length;
                        const st = coverageStatus(assigned, task.count);
                        return (
                          <button
                            key={task.id}
                            onClick={() => handleMove(editTarget.sid, task.id, 'tasks', assignMode)}
                            className={`w-full p-4 rounded-2xl text-[10px] font-black uppercase italic text-left flex items-center justify-between gap-3 hover:bg-white/10 ${coverageClass(st.tone)}`}
                            title={`Mangler: ${Math.max(0, task.count - assigned)} (krav ${task.count})`}
                          >
                            <span className="truncate">{task.label}</span>
                            <span className="text-[11px] opacity-80 tabular-nums">{st.label}</span>
                          </button>
                        );
                      })}</div></>
                  )}
                  {editTarget.type === 'cleaning' && (
                    <>{(() => {
                        const currentTarget = editTarget;
                        const currentSid = currentTarget.sid;
                        const s = students.find(x => x.id === currentSid); 
                        return (
                          <>
                            <button onClick={() => handleMove(currentSid, 'pool', 'cleaning', 'move')} className="w-full p-6 bg-[#00BFA5] text-black rounded-3xl font-black uppercase italic mb-4 shadow-xl">Flyt til egen gang (Puljen)</button>

                            <div className="flex items-center gap-2 mb-4">
                              <button
                                onClick={() => setAssignMode('move')}
                                className={`flex-1 p-3 rounded-2xl text-[10px] font-black uppercase italic transition ${assignMode==='move' ? 'bg-white/10 border border-white/20' : 'bg-white/5 border border-white/10 hover:bg-white/10'}`}
                              >Flyt</button>
                              <button
                                onClick={() => setAssignMode('add')}
                                className={`flex-1 p-3 rounded-2xl text-[10px] font-black uppercase italic transition ${assignMode==='add' ? 'bg-[#00BFA5]/15 border border-[#00BFA5]/30' : 'bg-white/5 border border-white/10 hover:bg-white/10'}`}
                              >Tilføj ekstra</button>
                            </div>

                            {(() => {
                              const a = getStudentAssignments(currentSid);
                              const hasExtra = a.extraTotal > 0;
                              return (
                                <div className={`text-[10px] font-black uppercase italic mb-4 p-4 rounded-2xl border ${hasExtra ? 'bg-[#D81B60]/10 border-[#D81B60]/30' : 'bg-white/5 border-white/10'} `}>
                                  <div className="flex items-center justify-between gap-3">
                                    <div className="flex items-center gap-2 opacity-70">
                                      <Utensils size={14} />
                                      <span className="truncate">Madtjanser: {a.tasks.length ? a.tasks.join(' • ') : '—'}</span>
                                    </div>
                                    <span className="tabular-nums opacity-80">{a.taskN}</span>
                                  </div>
                                  <div className="flex items-center justify-between gap-3 mt-2">
                                    <div className="flex items-center gap-2 opacity-70">
                                      <Trash2 size={14} />
                                      <span className="truncate">Fællesområder: {a.cleaning.length ? a.cleaning.join(' • ') : '—'}</span>
                                    </div>
                                    <span className="tabular-nums opacity-80">{a.cleanN}</span>
                                  </div>
                                  {hasExtra && (
                                    <div className="mt-3 flex items-center gap-2 text-[#D81B60]">
                                      <AlertCircle size={14} />
                                      <span>Ekstra opgaver: +{a.extraTotal}</span>
                                    </div>
                                  )}
                                </div>
                              );
                            })()}

                            <h4 className="text-[10px] font-black uppercase opacity-30 italic mb-2">Fællesområder</h4>
                            <div className="grid grid-cols-2 gap-2">
                              {cleaningAreasForPicker.map(area => {
                                const assigned = (cleaningAssignments[area.name] || []).length;
                                const st = coverageStatus(assigned, area.count);
                                return (
                                  <button
                                    key={area.name}
                                    onClick={() => handleMove(currentSid, area.name, 'cleaning', assignMode)}
                                    className={`p-3 rounded-xl text-[9px] font-black uppercase italic flex items-center justify-between gap-2 hover:bg-white/10 ${coverageClass(st.tone)}`}
                                    title={`Mangler: ${Math.max(0, area.count - assigned)} (krav ${area.count})`}
                                  >
                                    <span className="truncate">{area.name}</span>
                                    <span className="text-[10px] opacity-80 tabular-nums">{st.label}</span>
                                  </button>
                                );
                              })}
                            </div>
                            <h4 className="text-[10px] font-black uppercase opacity-30 italic mt-6 mb-2">Min Gang</h4>
                            <div className="grid grid-cols-1 gap-2">
                              {s && (
                                <button key={s.house} onClick={() => handleMove(currentSid, String(s.house), 'cleaning')} className="p-4 bg-white/5 rounded-xl text-[10px] font-black uppercase italic flex justify-between items-center">
                                  <span>{s.house}</span>
                                  <Check className="w-4 h-4 text-[#00BFA5]"/>
                                </button>
                              )}
                            </div>
                          </>
                        );
                      })()}</>
                  )}
               </div>
            </div>
          </div>
        )}

        {/* --- MODAL: INFO --- */}
        {showInfo && (
          <div className="fixed inset-0 bg-black/95 z-[6000] flex items-center justify-center p-4 backdrop-blur-md overflow-y-auto" onClick={() => setShowInfo(false)}>
             <div className="bg-[#151926] w-full max-w-[460px] rounded-[3rem] border border-white/10 shadow-2xl my-8" onClick={e => e.stopPropagation()}>
                <div className="p-8 border-b border-white/5 flex justify-between items-center">
                  <h2 className="text-2xl font-black uppercase text-[#FFB300] italic">Weekend Guide</h2>
                  <button onClick={() => setShowInfo(false)} className="p-3 bg-white/5 rounded-full active:scale-90 transition-transform"><X/></button>
                </div>
                <div className="p-8 space-y-10">
                  <section className="space-y-6">
                    <div className="flex items-center gap-3 text-[#00BFA5]"><BookOpen className="w-5 h-5"/><h3 className="font-black uppercase text-sm italic tracking-widest">Lærerens Flow</h3></div>
                    <div className="space-y-6 relative">
                      <div className="absolute left-[15px] top-2 bottom-2 w-0.5 bg-white/5"></div>
                      {[
                        { step: 1, icon: Database, title: "Importer Liste", text: "Hent ugens elevliste under Dashboard (Excel)." },
                        { step: 2, icon: Users, title: "Elevliste", text: "Tjek hvem der er tilstede og marker køkkenholdet." },
                        { step: 3, icon: Compass, title: "Gangrunder", text: "Tjek sovepladser. Gult 'FLYTTET' badge viser hvem der sover ude." },
                        { step: 4, icon: Dices, title: "Fordel Opgaver", text: "Ryst telefonen (eller tryk på terningen) for at tildele tjanser." },
                        { step: 5, icon: Printer, title: "Print & Del", text: "Generer program, brandlister og rengøringsskemaer." }
                      ].map((item, idx) => (
                        <div key={idx} className="flex gap-6 relative z-10">
                          <div className="w-8 h-8 rounded-full bg-white/10 border border-white/10 flex items-center justify-center shrink-0"><item.icon className="w-4 h-4 text-[#FFB300]"/></div>
                          <div><p className="font-black uppercase text-[10px] text-[#FFB300] italic mb-1">Trin {item.step}: {item.title}</p><p className="text-xs opacity-50 leading-relaxed">{item.text}</p></div>
                        </div>
                      ))}
                    </div>
                  </section>
                  <section className="bg-white/5 p-6 rounded-2xl border border-white/5 space-y-4">
                     <h4 className="font-black uppercase text-[10px] italic flex items-center gap-2"><MoveRight className="w-4 h-4 text-[#FFB300]"/> Gestures</h4>
                     <p className="text-xs opacity-50 italic">• Swipe H/V for at skifte fane.</p>
                     <p className="text-xs opacity-50 italic">• Swipe NED for at gå til Dashboard.</p>
                  </section>
                  <button onClick={() => { if(window.confirm("Vil du slette ALT data?")) { localStorage.clear(); window.location.reload(); } }} className="w-full py-5 bg-red-500/10 text-red-500 rounded-2xl font-black uppercase text-[10px] border border-red-500/20">Nulstil Appen</button>
                </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

const container = document.getElementById('root');
if (container) {
  const w = window as any;
  if (!w.__WEEKEND_HU_ROOT__) {
    w.__WEEKEND_HU_ROOT__ = ReactDOM.createRoot(container);
  }
  w.__WEEKEND_HU_ROOT__.render(<App />);
}